# Lab 5 — Fit the GLM Family to a Single Outcome: solution script
# The lab.qmd chunk code in chunk order, with the six TODOs (1a, 1b, 1c, 1d,
# 4a, 4b) completed. Run from the lab root (labs/lab5/):
#   Rscript solutions/solution.R
# Prints every checkpoint in the handout plus the extras the answer key
# quotes, and writes no files. No seeds: the lab is fully deterministic
# given the canonical Lab 1 dataset.

## ---- setup ------------------------------------------------------------
pacman::p_load(tidyverse, splines, sandwich, lmtest)

paths <- c("../lab1/data/derived/analytic_dataset.csv",  # Lab 1, completed in place
           "data/analytic_dataset.csv")                  # or the website copy
path <- paths[file.exists(paths)][1]
if (is.na(path)) {
  stop("analytic_dataset.csv not found. Complete Lab 1 first, or download ",
       "the dataset from the website into labs/lab5/data/.")
}
lab1 <- read_csv(path, show_col_types = FALSE)
cat("setup: nrow(lab1) =", nrow(lab1), "  # expect 1,292\n")
coh <- lab1 |> filter(!is.na(hospital_death))
cat("setup: nrow(coh)  =", nrow(coh), "  # expect 1,274\n")
# Lab 3's analytical sample: complete on baseline heart rate as well
dat <- coh |> drop_na(baseline_hr)
cat("setup: nrow(dat)  =", nrow(dat), "  # expect 1,271;",
    sum(dat$hospital_death), "deaths,", sum(dat$early_vasopressor), "exposed\n\n")

## ---- the shared right-hand side f (the handout defines it in the logistic
## chunk; the Step 0 parts list it belonged to was cut by the instructor 2026-10-13)
cat("The shared right-hand side f:\n")
f <- hospital_death ~ early_vasopressor + age + sex + baseline_map + baseline_hr
print(f)
cat("binomial()$link:", binomial()$link, " poisson()$link:", poisson()$link,
    " gaussian()$link:", gaussian()$link, "\n")
cat("binomial(link = 'log')$link:", binomial(link = "log")$link, "\n\n")

## ---- logistic (Step 1, provided) ---------------------------------------
cat("Step 1 — logistic:\n")
fit_lgt <- glm(f, family = binomial(link = "logit"), data = dat)
print(round(summary(fit_lgt)$coefficients, 4))
cat("iterations", fit_lgt$iter, " converged", fit_lgt$converged,
    " OR", round(exp(coef(fit_lgt)[["early_vasopressor"]]), 3),
    " # expect 6, TRUE, 1.535 (Lab 3's 1.54)\n")
cat("fitted range", round(range(fitted(fit_lgt)), 4), " deviance", round(deviance(fit_lgt), 2),
    " AIC", round(AIC(fit_lgt), 2), "  # expect 0.0048-0.6906, 781.62, 793.62\n\n")

## ---- logbin-default (Step 1, provided) ---------------------------------
cat("Step 1 — log-binomial at the default start:\n")
fit_lb0 <- tryCatch(
  glm(f, family = binomial(link = "log"), data = dat),
  error = function(e) conditionMessage(e))
cat("returns:", fit_lb0, "\n\n")

## ---- logbin-start (Step 1, TODO 1a) ------------------------------------
cat("Step 1 — log-binomial with starting values:\n")
# TODO (1a) completed: start = c(log(mean(dat$hospital_death)), rep(0, 5))
st <- c(log(mean(dat$hospital_death)), rep(0, 5))
cat("start vector:", round(st, 4), "  # intercept = log(136/1271) = -2.2349\n")
fit_lb25 <- withCallingHandlers(
  glm(f, family = binomial(link = "log"), data = dat, start = st),
  warning = function(w) { cat("  WARNING:", conditionMessage(w), "\n"); invokeRestart("muffleWarning") })
cat("default maxit: iterations", fit_lb25$iter, " converged", fit_lb25$converged,
    "  # expect 25, FALSE\n")
fit_lb <- withCallingHandlers(
  glm(f, family = binomial(link = "log"), data = dat, start = st,
      control = glm.control(maxit = 500)),
  warning = function(w) { cat("  WARNING:", conditionMessage(w), "\n"); invokeRestart("muffleWarning") })
cat("maxit = 500: iterations", fit_lb$iter, " converged", fit_lb$converged,
    "  # expect 29, TRUE\n")
print(round(summary(fit_lb)$coefficients, 4))
cat("RR", round(exp(coef(fit_lb)[["early_vasopressor"]]), 3),
    " max fitted", round(max(fitted(fit_lb)), 4),
    " fitted > 0.99:", sum(fitted(fit_lb) > 0.99),
    " deviance", round(deviance(fit_lb), 2), " AIC", round(AIC(fit_lb), 2),
    "  # expect 1.285, 0.9974, 1, 782.12, 794.12\n")
# the culprit: the same model without baseline heart rate converges unaided
fit_lb_nohr <- glm(hospital_death ~ early_vasopressor + age + sex + baseline_map,
                   family = binomial(link = "log"), data = dat)
cat("without baseline_hr: iterations", fit_lb_nohr$iter, " converged", fit_lb_nohr$converged,
    " RR", round(exp(coef(fit_lb_nohr)[["early_vasopressor"]]), 3),
    " max fitted", round(max(fitted(fit_lb_nohr)), 3),
    "  # expect 6, TRUE, 1.491, 0.422\n")
who <- which.max(fitted(fit_lb))
print(as.data.frame(dat[who, c("early_vasopressor", "age", "sex", "baseline_map",
                               "baseline_hr", "hospital_death")]))
cat("that patient's fitted risk: logistic", round(fitted(fit_lgt)[who], 3),
    " log-binomial", round(fitted(fit_lb)[who], 3), "  # expect 0.691 / 0.997\n")
cat("heart-rate range in the cohort:", range(dat$baseline_hr), "\n")
# key-only extra: sensitivity to the start
fit_lb_alt <- suppressWarnings(glm(f, family = binomial(link = "log"), data = dat,
                                   start = c(-5, rep(0, 5)), control = glm.control(maxit = 500)))
cat("alternative start (-5, 0...): iterations", fit_lb_alt$iter, " converged", fit_lb_alt$converged,
    " RR", round(exp(coef(fit_lb_alt)[["early_vasopressor"]]), 4), "\n\n")

## ---- poisson (Step 1, TODO 1b) ------------------------------------------
cat("Step 1 — Poisson, log link, no offset (the risk-ratio route):\n")
# TODO (1b) completed: family = poisson(link = "log")
fit_pois <- glm(f, family = poisson(link = "log"), data = dat)
print(round(summary(fit_pois)$coefficients, 4))
cat("iterations", fit_pois$iter, " RR", round(exp(coef(fit_pois)[["early_vasopressor"]]), 3),
    " max fitted", round(max(fitted(fit_pois)), 4), " fitted > 1:", sum(fitted(fit_pois) > 1),
    "  # expect 6, 1.408, 1.0059, 1\n")
rob <- coeftest(fit_pois, vcov = vcovHC(fit_pois, type = "HC3"))
cat("exposure SE: model", round(sqrt(vcov(fit_pois)[2, 2]), 4),
    " robust (HC3)", round(rob["early_vasopressor", "Std. Error"], 4),
    " logistic's", round(sqrt(vcov(fit_lgt)[2, 2]), 4),
    "  # expect 0.4254 / 0.405 / 0.5090\n")
cat("robust HC0 for reference:", round(sqrt(vcovHC(fit_pois, type = "HC0")[2, 2]), 4), "\n\n")

## ---- rate (Step 1, TODO 1c) ---------------------------------------------
cat("Step 1 — Poisson with the log person-time offset (the rate model):\n")
# TODO (1c) completed: offset(log(followup_days))
fit_rate <- glm(hospital_death ~ early_vasopressor + age + sex + baseline_map +
                  baseline_hr + offset(log(followup_days)),
                family = poisson(link = "log"), data = dat)
print(round(summary(fit_rate)$coefficients, 4))
cat("iterations", fit_rate$iter, " IRR", round(exp(coef(fit_rate)[["early_vasopressor"]]), 3),
    "  # expect 7, 1.384\n")
cat("fitted values: range", round(range(fitted(fit_rate)), 4), " n > 1:", sum(fitted(fit_rate) > 1),
    " sum", round(sum(fitted(fit_rate)), 2), " = deaths", sum(dat$hospital_death),
    "  # expect 0.0001-2.9498, 7, 136\n")
cat("robust (HC3) SE of the exposure coefficient:",
    round(sqrt(vcovHC(fit_rate, type = "HC3")[2, 2]), 4), " model", round(sqrt(vcov(fit_rate)[2, 2]), 4), "\n\n")

## ---- lpm (Step 1, TODO 1d) ----------------------------------------------
cat("Step 1 — linear probability model:\n")
# TODO (1d) completed: family = gaussian(link = "identity")
fit_lpm <- glm(f, family = gaussian(link = "identity"), data = dat)
print(round(summary(fit_lpm)$coefficients, 4))
cat("iterations", fit_lpm$iter, " RD", round(coef(fit_lpm)[["early_vasopressor"]], 4),
    "  # expect 2, 0.0713\n")
cat("fitted range", round(range(fitted(fit_lpm)), 4), " fitted < 0:", sum(fitted(fit_lpm) < 0),
    " fitted > 1:", sum(fitted(fit_lpm) > 1), "  # expect -0.1316-0.4263, 106, 0\n")
cat("same as lm()? max |coef diff| =", max(abs(coef(fit_lpm) - coef(lm(f, data = dat)))), "\n")
cat("exposure SE: model", round(sqrt(vcov(fit_lpm)[2, 2]), 4),
    " robust (HC3)", round(sqrt(vcovHC(fit_lpm, type = "HC3")[2, 2]), 4), "  # expect 0.0590 / 0.0823\n")
fit_id <- tryCatch(
  glm(f, family = binomial(link = "identity"), data = dat),
  error = function(e) conditionMessage(e))
cat("binomial identity link returns:", fit_id, "\n")
fit_id2 <- tryCatch(
  glm(f, family = binomial(link = "identity"), data = dat, start = coef(fit_lpm)),
  error = function(e) conditionMessage(e))
cat("...and with the least-squares coefficients as start:", fit_id2, "\n\n")

## ---- compare (Step 1, provided) ------------------------------------------
cat("Step 1 — the four fits side by side:\n")
row_of <- function(fit) {
  b  <- coef(fit)[["early_vasopressor"]]
  se <- sqrt(vcov(fit)["early_vasopressor", "early_vasopressor"])
  data.frame(family = fit$family$family, link = fit$family$link,
             iterations = fit$iter, converged = fit$converged,
             estimate = round(b, 4), exp_estimate = round(exp(b), 3), SE = round(se, 4))
}
compare <- rbind(logistic       = row_of(fit_lgt),
                 log_binomial   = row_of(fit_lb),
                 poisson        = row_of(fit_pois),
                 poisson_offset = row_of(fit_rate),
                 linear_prob    = row_of(fit_lpm))
print(compare)
cat("# expect exp(estimate) 1.535 / 1.285 / 1.408 / 1.384 / (RD 0.0713); iterations 6/29/6/7/2\n\n")

## ---- predicted (Step 2, provided) ---------------------------------------
cat("Step 2 — predicted probabilities:\n")
preds <- tibble(logistic = fitted(fit_lgt), log_binomial = fitted(fit_lb),
                poisson = fitted(fit_pois), linear_prob = fitted(fit_lpm))
summ <- sapply(preds, function(p) c(min = min(p), median = median(p), mean = mean(p),
                                    max = max(p), below_0 = sum(p < 0), above_1 = sum(p > 1)))
print(round(summ, 4))
cat("# expect means 0.1070 / 0.1066 / 0.1070 / 0.1070; max 0.6906 / 0.9974 / 1.0059 / 0.4263; below_0 106 for LPM\n")
cat("observed risk:", round(mean(dat$hospital_death), 4), "\n")
cat("sum of fitted values:", round(colSums(preds), 2), " vs 136 deaths  # 136.00 except the log-binomial\n")
print(round(cor(preds), 3))
cat("# expect logistic vs log-binomial 0.987, vs Poisson 0.987, vs LPM 0.909\n")
cat("rate model: mean fitted", round(mean(fitted(fit_rate)), 4), " max", round(max(fitted(fit_rate)), 3),
    " (expected deaths over each patient's own follow-up, not risks)\n")
# the patient with the most extreme predictions
ext <- order(-preds$logistic)[1]
cat("top-risk patient (row", ext, "):", unlist(dat[ext, c("early_vasopressor", "age", "sex", "baseline_map", "baseline_hr", "hospital_death")]), "\n")
cat("  logistic", round(preds$logistic[ext], 3), " log-binomial", round(preds$log_binomial[ext], 3),
    " Poisson", round(preds$poisson[ext], 3), " LPM", round(preds$linear_prob[ext], 3),
    "  # expect 0.691 / 0.997 / 1.006 / 0.426\n")
low <- order(preds$linear_prob)[1]
cat("lowest LPM patient (row", low, "):", unlist(dat[low, c("early_vasopressor", "age", "sex", "baseline_map", "baseline_hr", "hospital_death")]), "\n")
cat("  logistic", round(preds$logistic[low], 4), " LPM", round(preds$linear_prob[low], 4), "\n")
cat("LPM fitted < 0 by age: ", "max age among them", max(dat$age[preds$linear_prob < 0]),
    "; all unexposed?", all(dat$early_vasopressor[preds$linear_prob < 0] == 0), "\n")

## ---- fig-predicted (Step 2, provided) -----------------------------------
# reference patient: the profile of the top-risk patient, heart rate varied
ref <- data.frame(early_vasopressor = 0, age = 76, sex = "Male", baseline_map = 31,
                  baseline_hr = seq(40, 185, by = 1))
curves <- bind_rows(
  tibble(hr = ref$baseline_hr, risk = predict(fit_lgt,  ref, type = "response"), Model = "logistic"),
  tibble(hr = ref$baseline_hr, risk = predict(fit_lb,   ref, type = "response"), Model = "log-binomial"),
  tibble(hr = ref$baseline_hr, risk = predict(fit_pois, ref, type = "response"), Model = "Poisson (log)"),
  tibble(hr = ref$baseline_hr, risk = predict(fit_lpm,  ref, type = "response"), Model = "linear probability"))
cat("reference curves at HR 60 / 120 / 182:\n")
print(curves |> filter(hr %in% c(60, 120, 182)) |> pivot_wider(names_from = Model, values_from = risk) |>
        mutate(across(-hr, ~ round(.x, 3))) |> as.data.frame())
cat("HR at which the log-binomial curve passes 1:", min(curves$hr[curves$Model == "log-binomial" & curves$risk > 1]),
    " Poisson:", min(curves$hr[curves$Model == "Poisson (log)" & curves$risk > 1]), "\n\n")

## ---- three-ways (Step 3, provided) --------------------------------------
cat("Step 3 — one relationship in three ways:\n")
fit_lin <- glm(hospital_death ~ age,             family = binomial, data = dat)
fit_spl <- glm(hospital_death ~ ns(age, df = 4), family = binomial, data = dat)
fit_sat <- glm(hospital_death ~ factor(age),     family = binomial, data = dat)
spectrum <- data.frame(
  model      = c("linear", "natural spline (df = 4)", "saturated"),
  parameters = c(length(coef(fit_lin)), length(coef(fit_spl)), length(coef(fit_sat))),
  deviance   = round(c(deviance(fit_lin), deviance(fit_spl), deviance(fit_sat)), 2),
  AIC        = round(c(AIC(fit_lin), AIC(fit_spl), AIC(fit_sat)), 2))
print(spectrum)
cat("# expect 2/5/73; deviance 820.25/815.67/759.76; AIC 824.25/825.67/905.76\n")
cat("null deviance:", round(fit_lin$null.deviance, 2), "  # expect 864.79\n")
cat("ns knots:", attr(ns(dat$age, df = 4), "knots"), " boundary:",
    attr(ns(dat$age, df = 4), "Boundary.knots"), "  # expect 55 68 78; 18 90\n")
cat("LRT spline vs linear: diff", round(deviance(fit_lin) - deviance(fit_spl), 2),
    "on 3 df, p =", round(pchisq(deviance(fit_lin) - deviance(fit_spl), 3, lower.tail = FALSE), 3), "\n")
cat("LRT saturated vs spline: diff", round(deviance(fit_spl) - deviance(fit_sat), 2),
    "on", length(coef(fit_sat)) - length(coef(fit_spl)), "df, p =",
    round(pchisq(deviance(fit_spl) - deviance(fit_sat),
                 length(coef(fit_sat)) - length(coef(fit_spl)), lower.tail = FALSE), 3), "\n")
cat("saturated fit: iterations", fit_sat$iter, " converged", fit_sat$converged, "  # expect 17, TRUE\n")
by_age <- dat |>
  group_by(age) |>
  summarise(n = n(), deaths = sum(hospital_death), p_obs = mean(hospital_death))
by_age$p_sat <- predict(fit_sat, newdata = data.frame(age = by_age$age), type = "response")
cat("max |p_obs - saturated fit|:", signif(max(abs(by_age$p_obs - by_age$p_sat)), 2), "  # ~1e-8\n")
print(as.data.frame(by_age |> filter(age %in% c(18, 28, 44, 85, 88, 90))))
cat("# expect 0/7, 1/10, 0/3, 6/15, 1/13, 14/59\n")
cat("ages:", nrow(by_age), " with zero deaths:", sum(by_age$deaths == 0),
    " (patients:", sum(by_age$n[by_age$deaths == 0]), ")  n per age min/median/max",
    min(by_age$n), median(by_age$n), max(by_age$n), "\n")
print(round(summary(fit_sat)$coefficients[c("(Intercept)", "factor(age)19", "factor(age)28"), ], 2))
cat("# expect intercept ~ -18.6 with SE in the thousands; age 28 ~ +16.4\n")
# key-only extras
fit_dec <- glm(hospital_death ~ cut(age, c(18, 30, 40, 50, 60, 70, 80, 90),
                                    include.lowest = TRUE, right = FALSE),
               family = binomial, data = dat)
cat("decade bins: parameters", length(coef(fit_dec)), " deviance", round(deviance(fit_dec), 2),
    " AIC", round(AIC(fit_dec), 2), "\n")
nd61 <- data.frame(age = 61)
cat("fitted risk at age 61: linear", round(predict(fit_lin, nd61, type = "response"), 3),
    " spline", round(predict(fit_spl, nd61, type = "response"), 3),
    " saturated", round(predict(fit_sat, nd61, type = "response"), 3),
    " (", by_age$deaths[by_age$age == 61], "of", by_age$n[by_age$age == 61], "); at 60 saturated =",
    round(by_age$p_obs[by_age$age == 60], 3), "\n")
cat("exact 95% CI, age 85 (6/15):", round(binom.test(6, 15)$conf.int, 2),
    "; age 88 (1/13):", round(binom.test(1, 13)$conf.int, 2), "\n")

## ---- fig-spectrum (Step 3, provided): numbers only -----------------------
grid    <- data.frame(age = seq(18, 90, by = 0.5))
sat_grd <- data.frame(age = sort(unique(dat$age)))
cat("spline fitted at 18 / 40 / 70 / 90:",
    round(predict(fit_spl, data.frame(age = c(18, 40, 70, 90)), type = "response"), 3),
    " linear:", round(predict(fit_lin, data.frame(age = c(18, 40, 70, 90)), type = "response"), 3), "\n")

## ---- target-next-to-nuisance (Step 3, provided) -------------------------
cat("Step 3 — the target next to the nuisance (Step 1's model, age's form varied):\n")
or_row <- function(fit) {
  b  <- coef(fit)[["early_vasopressor"]]
  se <- sqrt(vcov(fit)["early_vasopressor", "early_vasopressor"])
  c(parameters = length(coef(fit)), logOR = b, SE = se, OR = exp(b),
    lcl = exp(b - 1.96 * se), ucl = exp(b + 1.96 * se))
}
print(round(rbind(
  age_linear    = or_row(fit_lgt),
  age_spline    = or_row(glm(hospital_death ~ early_vasopressor + ns(age, df = 4) + sex +
                               baseline_map + baseline_hr, family = binomial, data = dat)),
  age_saturated = or_row(glm(hospital_death ~ early_vasopressor + factor(age) + sex +
                               baseline_map + baseline_hr, family = binomial, data = dat))), 3))
cat("# expect OR 1.535 / 1.558 / 1.724; SE 0.509 / 0.508 / 0.545; parameters 6 / 9 / 77\n")
print(dat |>
        group_by(age) |>
        summarise(exposed = sum(early_vasopressor)) |>
        summarise(strata_with_an_exposed_patient = sum(exposed > 0)))
cat("# expect 19 of 73\n\n")

## ---- residuals (Step 4, TODO 4a) ----------------------------------------
cat("Step 4 — residual types (logistic model):\n")
mu <- fitted(fit_lgt)
# TODO (4a) completed: y - mu, and (y - mu) / sqrt(mu (1 - mu))
r_resp <- dat$hospital_death - mu
r_pear <- r_resp / sqrt(mu * (1 - mu))
r_dev  <- residuals(fit_lgt, type = "deviance")
cat("by hand vs residuals(): response", signif(max(abs(r_resp - residuals(fit_lgt, "response"))), 2),
    " pearson", signif(max(abs(r_pear - residuals(fit_lgt, "pearson"))), 2), "  # both ~0\n")
print(round(rbind(response = range(r_resp), pearson = range(r_pear), deviance = range(r_dev),
                  working = range(residuals(fit_lgt, "working"))), 3))
cat("# expect response -0.572..0.976; pearson -1.156..6.323; deviance -1.303..2.725; working -2.34..40.98\n")
cat("sum of squared deviance residuals", round(sum(r_dev^2), 2), " = deviance", round(deviance(fit_lgt), 2),
    "; sum of squared Pearson residuals", round(sum(r_pear^2), 2), "  # 781.62; 1249.43\n")
cat("largest Pearson residual: row", which.max(r_pear), " fitted", round(mu[which.max(r_pear)], 4),
    " died", dat$hospital_death[which.max(r_pear)], "; profile:",
    unlist(dat[which.max(r_pear), c("early_vasopressor", "age", "sex", "baseline_map", "baseline_hr")]), "\n")
bins <- dat |>
  mutate(p = mu, r = r_resp, bin = ntile(p, 10)) |>
  group_by(bin) |>
  summarise(n = n(), p_mean = mean(p), observed = mean(hospital_death),
            r_mean = mean(r), se = sqrt(p_mean * (1 - p_mean) / n), .groups = "drop")
print(as.data.frame(bins), digits = 3)
cat("bins with |mean residual| > 2 SE:", sum(abs(bins$r_mean) > 2 * bins$se), "  # expect 1 (decile 2)\n")
bins_age <- dat |>
  mutate(p = mu, r = r_resp, band = cut(age, c(17, seq(30, 80, 10), 91), right = FALSE)) |>
  group_by(band) |>
  summarise(n = n(), p_mean = mean(p), observed = mean(hospital_death),
            r_mean = mean(r), se = sqrt(p_mean * (1 - p_mean) / n), .groups = "drop")
print(as.data.frame(bins_age), digits = 3)
cat("# the 30s band: 0 of 73 died vs 0.028 expected (1.4 SE)\n\n")

## ---- leverage (Step 4, TODO 4b) -----------------------------------------
cat("Step 4 — leverage:\n")
h <- hatvalues(fit_lgt)
X <- model.matrix(fit_lgt)
# TODO (4b) completed: the working weights of the last IRLS iteration
w <- fit_lgt$weights
h_hand <- rowSums(((sqrt(w) * X) %*% solve(t(X) %*% (w * X))) * (sqrt(w) * X))
cat("by hand vs hatvalues(): max |diff|", signif(max(abs(h_hand - h)), 2), "  # ~1e-15\n")
cat("sum(h)", round(sum(h), 6), " = parameters", length(coef(fit_lgt)),
    "; mean", round(mean(h), 5), " = p/n", round(length(coef(fit_lgt)) / nrow(dat), 5),
    "; max", round(max(h), 4), "  # expect 6, 0.00472, 0.0765\n")
cat("patients above 2p/n:", sum(h > 2 * mean(h)), " above 3p/n:", sum(h > 3 * mean(h)), "  # expect 95, 55\n")
cat("working weights w = mu(1 - mu)? max |diff|", signif(max(abs(w - mu * (1 - mu))), 2), "\n")
sel <- c("early_vasopressor", "age", "sex", "baseline_map", "baseline_hr", "hospital_death")
top_h <- order(-h)[1:6]
print(cbind(as.data.frame(dat[top_h, sel]), leverage = round(h[top_h], 4), fitted = round(mu[top_h], 3)))
cat("# expect all six exposed; leverage 0.0765 down to 0.0608\n")
cat("mean leverage, exposed vs unexposed:", round(tapply(h, dat$early_vasopressor, mean), 4), "\n")
cat("how many of the 27 exposed sit in the top 27 leverages:", sum(dat$early_vasopressor[order(-h)[1:27]]), "\n\n")

## ---- cooks (Step 4, provided) --------------------------------------------
cat("Step 4 — Cook's distance:\n")
cd <- cooks.distance(fit_lgt)
cd_hand <- (r_pear^2 / length(coef(fit_lgt))) * h / (1 - h)^2
cat("by hand vs cooks.distance(): max |diff|", signif(max(abs(cd_hand - cd)), 2), "  # ~1e-17\n")
top_c <- order(-cd)[1:6]
print(cbind(as.data.frame(dat[top_c, sel]), leverage = round(h[top_c], 4),
            cooks = round(cd[top_c], 4), fitted = round(mu[top_c], 3)))
cat("# expect five exposed deaths (fitted 0.16-0.28) and the 28-year-old death; Cook's 0.0339 down to 0.0179\n")
ed <- which(dat$early_vasopressor == 1 & dat$hospital_death == 1)
cat("the six exposed deaths' Cook's ranks:", sort(rank(-cd)[ed]), "  # expect 1 2 3 4 5 7\n")
cat("max Cook's", round(max(cd), 4), "; patients above 4/n:", sum(cd > 4 / nrow(dat)), "  # 0.0339; 121\n")
fit_drop1 <- glm(f, family = binomial, data = dat[-top_c[1], ])
cat("drop the top patient: exposure coef", round(coef(fit_lgt)[["early_vasopressor"]], 4), "->",
    round(coef(fit_drop1)[["early_vasopressor"]], 4), "; OR", round(exp(coef(fit_lgt)[["early_vasopressor"]]), 3),
    "->", round(exp(coef(fit_drop1)[["early_vasopressor"]]), 3), "  # expect 0.4286 -> 0.2017; 1.535 -> 1.223\n")
cat("the other coefficients move by at most", signif(max(abs(coef(fit_lgt)[-2] - coef(fit_drop1)[-2])), 2), "\n")
# key-only extras
fit_drop6 <- glm(f, family = binomial, data = dat[-top_c, ])
cat("drop all six: exposure OR", round(exp(coef(fit_drop6)[["early_vasopressor"]]), 3), "(five of six exposed deaths gone)\n")
fit_dropall <- glm(f, family = binomial, data = dat[-ed, ])
cat("drop the six exposed deaths: exposure coef", round(coef(fit_dropall)[["early_vasopressor"]], 2),
    " SE", round(sqrt(vcov(fit_dropall)[2, 2]), 1), " (separation: no exposed deaths left)\n")
# the LPM's residuals carry the binomial variance function
cat("LPM residual variance by tertile of fitted risk:",
    round(tapply(residuals(fit_lpm), ntile(fitted(fit_lpm), 3), var), 4), "  # expect 0.041 / 0.066 / 0.160\n")
cat("mu(1-mu) at the tertile means:",
    round(tapply(fitted(fit_lpm), ntile(fitted(fit_lpm), 3), function(m) mean(m) * (1 - mean(m))), 4), "\n")
cat("\nR", R.version.string, "\n")
