# Lab 2 — Three Ways to Sample Controls

A continuation of Lab 1. Treat the Lab 1 analytic dataset (1,292 ICU
stays; early vasopressor initiation; in-hospital death) as a fully
enumerated source cohort, compute its risk ratio, odds ratio, and rate
ratio directly, then draw three case-control samples that keep all 136
cases and differ only in how controls are chosen:

- **cumulative (survivor) sampling** → the exposure odds ratio recovers
  the cohort **odds ratio** (2.46);
- **case-base sampling** → it recovers the cohort **risk ratio** (2.13);
- **incidence-density (risk-set) sampling** → it recovers the cohort
  **rate ratio** (2.00).

Because the outcome is not rare, the three targets are visibly different
numbers — the same cross-product arithmetic estimates a different cohort
parameter under each scheme, and the full cohort lets you check every
claim. A 500-replicate step shows the correspondence "in expectation,"
and a final chunk saves the three case-control datasets, which Week 11's
lab reuses with regression tools.

## Quick start

1. Open `lab2.Rproj` in RStudio.
2. The lab reads your **Lab 1** output. If `labs/lab1/` sits next to this
   folder with its pipeline completed, nothing else is needed; otherwise
   download `analytic_dataset.csv` from CANVAS into `labs/lab2/data/`.
3. Packages: tidyverse only (`pacman::p_load(tidyverse)`).
4. Open `lab.qmd` and work top to bottom, completing the `TODO` chunks
   (they contain `???` placeholders and error until fixed) and answering
   the questions in the answer blocks.
5. When every chunk runs, flip `eval: false` to `eval: true` in the YAML
   header and render to HTML.

Deliverables are **yours to keep** — the rendered HTML and the three
saved datasets are not submitted; keep them for exam preparation and for
Week 11.

Every sampling chunk sets its own seed (do not change them; all
checkpoints depend on them), so any chunk can be re-run on its own.

## Folder layout

```
lab.qmd        the lab document — start here
lab2.Rproj     RStudio project anchor
data/          created by the lab: caco_cumulative.csv, caco_casebase.csv,
               caco_density.csv (reused in Week 11); also where a CANVAS
               copy of analytic_dataset.csv goes if you need one
```

## Data source

The cohort is the Lab 1 analytic dataset, derived from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet;
doi:10.13026/4mxk-na84; ODbL license) — see `labs/lab1/README.md` for
full provenance and citation.
