# Lab 2 — The Case-Cohort Design

A continuation of Lab 1. Treat the Lab 1 analytic dataset (1,292 ICU
stays; early vasopressor initiation; in-hospital death) as a fully
enumerated source cohort in which the exposure is *pretend-expensive*
(~\$150 per chart to abstract). Draw a case-cohort sample — a 20% random
subcohort plus all 136 cases (367 charts instead of 1,274) — weight it
back up to the cohort, and check every estimate against the directly
computed truth:

- the **risk function** (cumulative risk curve), by weighted
  Kaplan-Meier on time-varying weights in counting-process format;
- the **risk ratio** (2.13), by weighted log-Poisson ("modified
  Poisson") regression;
- the **risk difference** (0.118), by a weighted linear risk model —

all with robust (sandwich) standard errors, against naive model-based
ones that falsely report full-cohort precision. A deliberate-mistake
step keeps all the cases' person-time at full weight and shows what
breaks (absolute risks and rates, by ~10%) and which design check
catches it (weighted person-time vs. the cohort's). A 2,000-replicate
step shows the design recovers the truth "in expectation," and a final
chunk saves the case-cohort sample, which Week 11's lab reuses.

## Quick start

1. Open `lab2.Rproj` in RStudio.
2. The lab reads your **Lab 1** output. If `labs/lab1/` sits next to this
   folder with its pipeline completed, nothing else is needed; otherwise
   download `analytic_dataset.csv` from CANVAS into `labs/lab2/data/`.
3. Packages: `pacman::p_load(tidyverse, survival, sandwich, lmtest)`.
4. Open `lab.qmd` and work top to bottom, completing the `TODO` chunks
   (they contain `???` placeholders and error until fixed) and answering
   the questions in the answer blocks.
5. When every chunk runs, flip `eval: false` to `eval: true` in the YAML
   header and render to HTML.

Deliverables are **yours to keep** — the rendered HTML and the saved
case-cohort sample are not submitted; keep them for exam preparation and
for Week 11.

Every sampling chunk sets its own seed (do not change them; all
checkpoints depend on them), so any chunk can be re-run on its own.

## Folder layout

```
lab.qmd        the lab document — start here
lab2.Rproj     RStudio project anchor
data/          created by the lab: case_cohort_sample.csv (reused in
               Week 11); also where a CANVAS copy of
               analytic_dataset.csv goes if you need one
```

## Data source

The cohort is the Lab 1 analytic dataset, derived from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet;
doi:10.13026/4mxk-na84; ODbL license) — see `labs/lab1/README.md` for
full provenance and citation.
