# Codebook — `analytic_dataset.csv`

One row per eligible ICU stay (**n = 1,292**; `patientunitstayid` is
unique). Built by the Lab 1 pipeline (`labs/lab1/R/01–04`) from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet, ODbL). Eligible =
adult (≥ 18) **first** ICU stay, with a valid hypotensive MAP reading
during the stay (= time zero), **no** vasopressor infusion before time
zero (new users only), and still in the ICU 60 minutes after time zero
(the landmark). All `*_offset` variables are integer **minutes since ICU
unit admission** (admission = 0).

| variable | values / units | what it is, and how it was built |
|---|---|---|
| `patientunitstayid` | integer | eICU ICU-stay identifier (one stay per row). |
| `time_zero_offset` | minutes | **Time zero**: the stay's first valid MAP < 65 mmHg. Valid = 30–150 mmHg, at/after admission; invasive (`vitalPeriodic$systemicmean`) and cuff (`vitalAperiodic$noninvasivemean`) readings pooled into one series. |
| `landmark_offset` | minutes | `time_zero_offset + 60`. **Start of follow-up**; every row was still in the ICU at this moment (eligibility filter). |
| `early_vasopressor` | 0/1 (27 ones) | **Exposure**: 1 if the first qualifying vasopressor infusion falls within [t0, t0 + 60]. Qualifying = norepinephrine, epinephrine, phenylephrine, vasopressin, or dopamine, matched by regex (generic + brand spellings) on the free-text `infusiondrug$drugname`. |
| `first_vasopressor_offset` | minutes; NA if none (1,157 NA) | First qualifying infusion at/after time zero — the timing behind the exposure classification. (Anyone infused *before* time zero was excluded as a prevalent user.) |
| `hospital_death` | 1/0/NA (136/1,138/18) | **Primary outcome**: hospital discharge status "Expired" = 1, "Alive" = 0, blank = NA. |
| `death_event` | 1/0/NA | Identical copy of `hospital_death`, kept as the event indicator for time-to-event analyses. |
| `followup_days` | days, decimal (0.004–99.3) | `(hospitaldischargeoffset − landmark_offset) / 1440`: landmark to hospital discharge, dead or alive. No separate censoring indicator — live discharge simply ends follow-up. |
| `age` | years, 18–90 | From the patient table; the de-identification mask "> 89" recoded to 90 (n = 59). |
| `sex` | "Male"/"Female" | Patient-table `gender`; blanks were set to NA (none remain after eligibility). |
| `baseline_map` | mmHg, 30–64 | The index MAP reading itself — the value that defined time zero, so always < 65. |
| `baseline_map_source` | "cuff" (1,177) / "invasive" (115) | Which series the index reading came from: cuff (`noninvasivemean`) vs. arterial line (`systemicmean`). |
| `baseline_hr` | beats/min; 3 NA | Heart rate nearest to time zero within ±60 minutes (`vitalPeriodic$heartrate`; ties go to the earlier reading); NA if none in the window. |

Note for Lab 4: analyses drop the 18 stays with NA `hospital_death`
before doing anything else (complete-case cohort n = 1,274). No model
in this lab uses `baseline_hr`, so, unlike Lab 3, no further rows are
lost. `followup_days` is the person-time in the Step-2 rate model
(7,478.4 person-days in total), and `age` (73 distinct values, 18–90,
with everyone over 89 recoded to 90) is the covariate whose functional
form Steps 3–4 vary. This copy of the file is Lab 1's
`data/derived/analytic_dataset.csv`; regenerate it by running the Lab 1
pipeline.
