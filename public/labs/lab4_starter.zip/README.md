# Lab 4 — Dissect a Regression Model

A lab about the *parts* of a regression model, practiced on the Lab 1
cohort (1,292 ICU stays; early vasopressor initiation; in-hospital
death; 1,274 after dropping blank outcomes). Nothing about the cohort
changes; one dial of one model is turned at a time, with everything
else held fixed, and the lab watches which numbers move:

- **the link** (identity → log → logit). With the exposure alone the
  three binomial fits are saturated and return identical fitted values
  (0.1042 / 0.2222) and deviances; only the coefficient's meaning
  changes (RD 0.118, RR 2.13, OR 2.45 — Lab 2's and Lab 3's numbers).
  With age on the right-hand side the compression becomes lossy
  (Greenland's image) and the links disagree about what to keep: a
  straight line (one risk difference per year), an exponential (one risk
  ratio), a sigmoid (one odds ratio). The identity-link `glm()` refuses to start
  (zero deaths under age 28 → negative fitted risk), a preview of Lab 5;
- **the offset**. A Poisson model without one returns Lab 2's risk ratio
  (2.13); with `offset(log(followup_days))` it returns the hand-computed
  rate ratio (2.00) exactly. Setting the offset's coefficient free
  (−0.23, not 1) shows what the offset literally is, and a two-row
  aggregated refit shows what the rate model actually uses;
- **the flexibility of the right-hand side**. Death against age fit
  three ways — linear (2 parameters), natural cubic spline (5),
  saturated (73, the NPMLE). The saturated fit equals the stratum
  proportions to 1e−8 under any link; deviance 820.6 / 816.0 / 760.2,
  AIC 824.6 / 826.0 / 906.2;
- **the spectrum, visualized**, and the exposure OR next to each age
  term (2.16 / 2.14 / 2.37, SE 0.48 / 0.48 / 0.52): the target barely
  moves until the nuisance is saturated, and only 19 of 73 age strata
  contain an exposed patient.

## Quick start

1. Open `lab4.Rproj` in RStudio.
2. The lab reads your **Lab 1** output. If `labs/lab1/` sits next to
   this folder with its pipeline completed, nothing else is needed;
   otherwise use the copy of `analytic_dataset.csv` that ships in this
   starter package's `data/` folder (downloaded from the course site).
3. Packages: `pacman::p_load(tidyverse, splines)` — `splines` ships
   with R.
4. Open `lab.qmd` and work top to bottom. Four chunks contain `TODO`s
   (with `???` placeholders that error until fixed); everything else is
   provided, and the work is in the questions.
5. When the `TODO` chunks run, flip `eval: false` to `eval: true` in
   the YAML header and render to HTML.

Deliverables are **yours to keep** — the rendered HTML is not
submitted; keep it for exam preparation.

## Folder layout

```
lab.qmd        the lab document — start here
lab4.Rproj     RStudio project anchor
data/          a copy of Lab 1's analytic_dataset.csv (plus its codebook)
               for anyone without a completed Lab 1
```

## Data source

The cohort is the Lab 1 analytic dataset, derived from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet;
doi:10.13026/4mxk-na84; ODbL license) — see `labs/lab1/README.md` for
full provenance and citation.

## Readings the lab leans on

- The Week 5 lecture notes, *The Anatomy of a Regression Model*.
- Clark & Berry, *Models Demystified*, chapters 2–4 (reading list).
- Naimi & Whitcomb, *Am J Epidemiol* 2020 (risk ratios and risk
  differences by regression) — Step 1.
- Zou, *Am J Epidemiol* 2004 (modified Poisson regression) — Step 2.
