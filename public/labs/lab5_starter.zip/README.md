# Lab 5 — Fit the GLM Family to a Single Outcome

A lab about the *family*: one cohort (the Lab 1 ICU cohort, 1,292
stays; 1,274 with a recorded outcome; 1,271 with a baseline heart rate,
the rows Lab 3's model used), one outcome (in-hospital death), one
right-hand side (Lab 3's: early vasopressor initiation, age, sex,
baseline MAP, baseline heart rate), and four distribution-and-link
pairs run through the same fitting loop:

- **logistic** (binomial, logit): OR 1.54, 6 iterations, fitted risks
  0.005 to 0.69;
- **log-binomial** (binomial, log): refuses to start; with the lecture's
  starting values it stops unconverged at 25 iterations and converges
  at 29 once the limit is raised, RR 1.29, with one fitted risk at
  0.997 (the patient with the cohort's maximum heart rate, 182). Drop
  heart rate and it converges unaided;
- **Poisson, log link**, no offset (Zou's route): RR 1.41 in 6
  iterations, one fitted "risk" of 1.006, model-based SE 0.425 vs.
  robust 0.405; with `offset(log(followup_days))` the same machine
  reports a rate ratio, 1.38, and fitted values that are expected
  deaths over each patient's own follow-up (they sum to 136);
- **linear probability** (Gaussian, identity): RD 0.071, 2 iterations,
  106 negative fitted risks; the binomial-identity version never
  starts.

Then the right-hand side's flexibility dial, carried over from the Lab 4
handout that was not run in class: death against age fit **three
ways**, linear (2 parameters), natural cubic spline (5), saturated (73,
the NPMLE); deviance 820.3 / 815.7 / 759.8, AIC 824.3 / 825.7 / 905.8;
the saturated fit equals the by-age proportions to 1e−8 and shows the
lecture's *separation* in its printout (30 ages with no deaths);
the exposure OR next to each age term: 1.54 / 1.56 / 1.72 (SE 0.51 /
0.51 / 0.55), with only 19 of 73 age strata containing an exposed
patient.

Last, the diagnostics the lecture named but did not show, on the
logistic fit: residuals in four currencies (by hand, then
`residuals()`), the hat diagonal from the last iteration's weights (by
hand, then `hatvalues()`; the six highest-leverage patients are all
exposed), and Cook's distance (five of the six most influential patients
are the exposed deaths; dropping one moves the OR from 1.54 to 1.22).

## Quick start

1. Open `lab5.Rproj` in RStudio.
2. The lab reads your **Lab 1** output. If `labs/lab1/` sits next to
   this folder with its pipeline completed, nothing else is needed;
   otherwise use the copy of `analytic_dataset.csv` that ships in this
   starter package's `data/` folder (downloaded from the course site).
3. Packages: `pacman::p_load(tidyverse, splines, sandwich, lmtest)`
   (`splines` ships with R; `sandwich` and `lmtest` were Lab 2's).
4. Open `lab.qmd` and work top to bottom. Six chunks contain `TODO`s
   (with `???` placeholders that error until fixed); everything else is
   provided, and much of the work is in the questions.
5. When the `TODO` chunks run, flip `eval: false` to `eval: true` in
   the YAML header and render to HTML. The log-binomial chunk prints
   warnings when it runs; they are part of the lesson, not a mistake.

Deliverables are **yours to keep** — the rendered HTML is not
submitted; keep it for exam preparation.

## Folder layout

```
lab.qmd        the lab document — start here
lab5.Rproj     RStudio project anchor
data/          a copy of Lab 1's analytic_dataset.csv (plus its codebook)
               for anyone without a completed Lab 1
```

## Data source

The cohort is the Lab 1 analytic dataset, derived from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet;
doi:10.13026/4mxk-na84; ODbL license) — see `labs/lab1/README.md` for
full provenance and citation.

## Readings the lab leans on

- The Week 6 lecture notes, *Generalized Linear Models*.
- Clark & Berry, *Models Demystified*, chapter 8 (reading list).
- Zou, *Am J Epidemiol* 2004 (the Poisson route to a risk ratio) —
  Step 1.
- Greenland, *Stat Med* 2025 (the lossy-compression image) — Step 3.
- Pregibon, *Ann Stat* 1981 (logistic regression diagnostics) — Step 4.
