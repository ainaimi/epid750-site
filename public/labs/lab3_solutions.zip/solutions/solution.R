# Lab 3 — Three Questions: solution script
# The lab.qmd chunk code in chunk order, with both TODOs completed.
# Run from the lab root (labs/lab3/): Rscript solutions/solution.R
# Prints every checkpoint in the handout, including the two AICs Q2 quotes.

## ---- setup ------------------------------------------------------------
pacman::p_load(tidyverse)

paths <- c("../lab1/data/derived/analytic_dataset.csv",  # Lab 1, completed in place
           "data/analytic_dataset.csv")                  # or the website copy
path <- paths[file.exists(paths)][1]
if (is.na(path)) {
  stop("analytic_dataset.csv not found. Complete Lab 1 first, or download ",
       "the dataset from the website into labs/lab3/data/.")
}
lab1 <- read_csv(path, show_col_types = FALSE)
cat("setup: nrow(lab1) =", nrow(lab1), "  # expect 1,292\n")

coh <- lab1 |> filter(!is.na(hospital_death))
cat("setup: nrow(coh)  =", nrow(coh), "  # expect 1,274\n\n")

## ---- fit-the-model (Step 0) --------------------------------------------
fit <- glm(hospital_death ~ early_vasopressor + age + sex +
             baseline_map + baseline_hr,
           family = binomial, data = coh)

cat("Step 0 — the printout:\n")
print(round(summary(fit)$coefficients, 3))
cat("as odds ratios:\n")
print(round(exp(coef(fit)), 3))
cat("nobs(fit):", nobs(fit), "  # expect 1,271 — three rows silently dropped",
    "(missing baseline_hr)\n")
cat("AIC(fit):", round(AIC(fit), 2),
    "  # expect 793.62 — Q2's 'adjusted model' AIC\n\n")

## ---- descriptive-estimates (Step 1) --------------------------------------
cat("Step 1 — descriptive readings:\n")
cat("proportion:", round(sum(coh$hospital_death) / nrow(coh), 4),
    "  # expect 0.107 = 136/1,274\n")

# TODO (1a) completed: the intercept-only ("null") model is "~ 1"
fit0 <- glm(hospital_death ~ 1, family = binomial(link = "logit"), data = coh)
cat("plogis(intercept-only):", round(plogis(coef(fit0)), 4),
    "  # expect 0.107 — identical\n")
cat("nobs(fit0):", nobs(fit0), "  # expect 1,274 — this model dropped nobody\n")
cat("AIC(fit0):", round(AIC(fit0), 2),
    "  # expect 867.47 — Q2's 'null model' AIC\n")
# Q2 subtlety: fit0 used 1,274 rows, fit used 1,271. AICs only compare
# models fit to the same data; the like-for-like null AIC is fit's null
# deviance + 2 (one parameter).
cat("AIC, intercept-only on fit's 1,271 rows:", round(fit$null.deviance + 2, 2),
    "  # expect 866.79\n")

coh |>
  group_by(sex) |>
  summarise(n = n(), deaths = sum(hospital_death),
            risk = round(mean(hospital_death), 3)) |>
  print()
cat("# expect Male 86/754 = 0.114, Female 50/520 = 0.096; crude OR ~ 1.21\n")
cat("crude sex OR:",
    round((86/668) / (50/470), 2),
    " vs. model sexMale OR:", round(exp(coef(fit)["sexMale"]), 2), "\n\n")

## ---- predictive-performance (Step 2) --------------------------------------
cat("Step 2 — predictive readings:\n")
# AUC = P(random death outranks random survivor in predicted risk)
auc_fun <- function(p, y) {
  r <- rank(p); n1 <- sum(y == 1); n0 <- sum(y == 0)
  (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

# do consciously what glm() did silently in Step 0
dat_model <- coh |> drop_na(baseline_hr)

p_full <- predict(fit, newdata = dat_model, type = "response")
cat("mean predicted:", round(mean(p_full), 4),
    " observed:", round(mean(dat_model$hospital_death), 4),
    "  # equal by construction (in-sample MLE)\n")
cat("AUC, full model:", round(auc_fun(p_full, dat_model$hospital_death), 4),
    "  # expect 0.7246\n")

# TODO (2a) completed: same rows, exposure removed
fit_noexp <- glm(hospital_death ~ age + sex + baseline_map + baseline_hr,
                 family = binomial, data = dat_model)
cat("AUC, without early_vasopressor:",
    round(auc_fun(predict(fit_noexp, type = "response"),
                  dat_model$hospital_death), 4),
    "  # expect 0.7225\n")

fit_only <- glm(hospital_death ~ early_vasopressor,
                family = binomial, data = dat_model)
cat("AUC, exposure alone:",
    round(auc_fun(predict(fit_only, type = "response"),
                  dat_model$hospital_death), 4),
    "  # expect 0.5128\n\n")

## ---- causal-reading (Step 3) -----------------------------------------------
cat("Step 3 — causal reading:\n")
b  <- coef(fit)["early_vasopressor"]
se <- summary(fit)$coefficients["early_vasopressor", "Std. Error"]
print(round(c(logOR = unname(b), SE = unname(se), OR = unname(exp(b)),
              lcl = unname(exp(b - 1.96 * se)),
              ucl = unname(exp(b + 1.96 * se))), 2))
cat("# expect OR 1.54, CI 0.57–4.16\n")
print(with(coh, table(early_vasopressor, hospital_death)))
cat("# expect 21/6 exposed, 1,117/130 unexposed; crude OR",
    round((6/21) / (130/1117), 2),
    " (exact 2.4549)\n")
