# Lab 6 — Compute Variance Three Ways: solution script
# The lab.qmd chunk code in chunk order, with the four TODOs (1a, 1b, 2a, 3a)
# completed. Run from the lab root (labs/lab6/):
#   Rscript solutions/solution.R
# Prints every checkpoint in the handout plus the extras the answer key
# quotes. No data files are read: the lab simulates everything it uses.
# Every chunk that draws random numbers sets its own seed, so the numbers
# below reproduce exactly on any machine running the same R (4.x) RNG.

## ---- setup ------------------------------------------------------------
pacman::p_load(tidyverse, sandwich, lmtest, boot)

expit <- function(x) 1 / (1 + exp(-x))

# One sample from the super-population. The truth is written in the code:
# the exposure coefficient is 2, and the error SD depends on exposure.
make_data <- function(n, sd_exposed = 2, sd_unexposed = 1) {
  z     <- rnorm(n)                                    # a confounder
  x     <- rbinom(n, 1, expit(-1.5 + 0.8 * z))         # exposure: ~21%, more common at high z
  sigma <- ifelse(x == 1, sd_exposed, sd_unexposed)    # the error SD, by exposure group
  y     <- 1 + 2 * x + 1.5 * z + rnorm(n, 0, sigma)    # the outcome; beta_x = 2 is the truth
  data.frame(y, x, z)
}

set.seed(785)
big <- make_data(1e5)
cat("setup: exposure prevalence in 100,000 draws =", round(mean(big$x), 3),
    " (expect about 0.21)\n")
cat("setup: error SD by group in those draws (y minus its mean):",
    round(tapply(big$y - (1 + 2 * big$x + 1.5 * big$z), big$x, sd), 3), "  # expect 1, 2\n\n")

## ---- one-sample (Step 1, provided) --------------------------------------
cat("Step 1 — one sample of 300:\n")
set.seed(785)
dat <- make_data(n = 300)
cat("n exposed:", sum(dat$x), "\n")
fit <- lm(y ~ x + z, data = dat)
print(round(summary(fit)$coefficients, 4))
cat("residual SD by exposure group:", round(tapply(resid(fit), dat$x, sd), 3), "  # truth 1, 2\n\n")

## ---- by-hand (Step 1, TODO 1a) -------------------------------------------
cat("Step 1 — the model-based sandwich by hand:\n")
X <- model.matrix(fit)            # n x 3: intercept, x, z
y <- dat$y
n <- nrow(X); p <- ncol(X)

beta_hat <- solve(t(X) %*% X) %*% t(X) %*% y
cat("max |beta_hat - coef(fit)|:", max(abs(beta_hat - coef(fit))), "  # zero\n")

u <- as.vector(y - X %*% beta_hat)                      # the residuals
bread <- solve(t(X) %*% X)                              # (X'X)^-1

# TODO (1a) completed: s2 = sum of squared residuals over residual df
s2 <- sum(u^2) / (n - p)
cat("s2 =", round(s2, 4), "  # the one number the model-based Sigma uses for everyone\n")
Sigma_model <- diag(s2, n)                              # s2 on the diagonal, zeros elsewhere
V_model <- bread %*% (t(X) %*% Sigma_model %*% X) %*% bread
cat("max |V_model - vcov(fit)|:", max(abs(V_model - vcov(fit))), "  # zero\n")
cat("SE(x), by hand:", round(sqrt(V_model["x", "x"]), 4),
    " vcov():", round(sqrt(vcov(fit)["x", "x"]), 4), "\n\n")

## ---- robust-by-hand (Step 1, TODO 1b) ------------------------------------
cat("Step 1 — the robust sandwich by hand:\n")
h <- diag(X %*% bread %*% t(X))                         # leverage
cat("max |h - hatvalues(fit)|:", max(abs(h - hatvalues(fit))), "  sum(h) =", round(sum(h), 6),
    " # zero; p = 3\n")

# TODO (1b) completed: HC0 uses each person's squared residual; HC3 divides it by (1 - h)^2
Sigma_hc0 <- diag(u^2, n)
Sigma_hc3 <- diag(u^2 / (1 - h)^2, n)

V_hc0 <- bread %*% (t(X) %*% Sigma_hc0 %*% X) %*% bread
V_hc3 <- bread %*% (t(X) %*% Sigma_hc3 %*% X) %*% bread

cat("max |V_hc0 - vcovHC(HC0)|:", max(abs(V_hc0 - vcovHC(fit, type = "HC0"))), "\n")
cat("max |V_hc3 - vcovHC(HC3)|:", max(abs(V_hc3 - vcovHC(fit, type = "HC3"))), "\n")
se_tab <- c(model = sqrt(V_model["x", "x"]), HC0 = sqrt(V_hc0["x", "x"]), HC3 = sqrt(V_hc3["x", "x"]))
cat("SE(x): model", round(se_tab[1], 4), " HC0", round(se_tab[2], 4), " HC3", round(se_tab[3], 4), "\n")
cat("diagonal of Sigma: model-based is", round(s2, 3), "for everyone; HC0 runs from",
    round(min(u^2), 4), "to", round(max(u^2), 3), "\n")
cat("mean squared residual by group:", round(tapply(u^2, dat$x, mean), 3), "\n\n")

## ---- hc-variants (Step 1, provided) --------------------------------------
cat("Step 1 — the HC family on this sample:\n")
hc <- sapply(c("const", "HC0", "HC1", "HC2", "HC3"),
             function(type) sqrt(vcovHC(fit, type = type)["x", "x"]))
print(round(hc, 4))
cat("HC1 = HC0 * sqrt(n/(n-p)):", round(hc["HC0"] * sqrt(n / (n - p)), 4), "\n")
cat("leverage range:", round(range(h), 4), " mean", round(mean(h), 4), " = p/n", round(p / n, 4), "\n")
cat("mean leverage by group:", round(tapply(h, dat$x, mean), 4), "\n")
print(coeftest(fit, vcov = vcovHC(fit, type = "HC3"))["x", ])
cat("\n")

## ---- software-defaults (Step 1, provided) --------------------------------
cat("Step 1 — what R, Stata, and SAS print by default (reproduced by formula):\n")
write_csv(dat, "lab6_sample.csv")                      # the sample, for Stata or SAS

se_of <- function(type) sqrt(vcovHC(fit, type = type)["x", "x"])
print(tribble(
  ~software, ~command,                                      ~variant,
  "R",       "vcovHC(fit)                     (the default)", "HC3",
  "R",       "sandwich(fit)",                                 "HC0",
  "Stata",   "regress y x z, vce(robust)",                    "HC1",
  "Stata",   "regress y x z, vce(hc3)",                       "HC3",
  "SAS",     "proc reg; model y = x z / hcc hccmethod=0;",    "HC0",
  "SAS",     "proc reg; model y = x z / hcc hccmethod=3;",    "HC3",
  "SAS",     "proc genmod; ...; repeated subject=id;",        "HC0") |>
  mutate(SE = round(sapply(variant, se_of), 4)) |>
  as.data.frame())
cat("key-only: sandwich(fit) really is HC0:", sqrt(sandwich(fit)["x", "x"]), "\n")
cat("key-only: HC1 = HC0 * sqrt(n/(n-p)):", round(se_of("HC0") * sqrt(n / (n - p)), 6), " vs", round(se_of("HC1"), 6), "\n")
cat("key-only: Stata ML-command robust (HC0 * n/(n-1)), had this been glm/poisson:",
    round(se_of("HC0") * sqrt(n / (n - 1)), 4), "\n")
cat("key-only: vcovCL with one row per cluster, no adjustment, = HC0 (the GENMOD subject=id device):",
    round(sqrt(vcovCL(fit, cluster = seq_len(n), type = "HC0", cadjust = FALSE)["x", "x"]), 6), "\n\n")

## ---- summarise-sim (Step 2, TODO 2a) ------------------------------------
cat("Step 2 — the simulation engine:\n")
summarise_sim <- function(res, truth = 2) {
  se_cols <- grep("^se_", names(res), value = TRUE)
  out <- c(mean_estimate = mean(res$estimate), sd_estimate = sd(res$estimate))
  for (s in se_cols) {
    # TODO (2a) completed: the 95% Wald interval, estimate +/- 1.96 se, contains the truth
    covered <- abs(res$estimate - truth) <= 1.96 * res[[s]]
    out[paste0("mean_", s)]               <- mean(res[[s]])
    out[paste0("cov_", sub("se_", "", s))] <- mean(covered)
  }
  round(out, 3)
}

simulate <- function(R, n, sd_exposed, sd_unexposed, seed = 785) {
  set.seed(seed)
  res <- vector("list", R)
  for (r in 1:R) {
    d   <- make_data(n, sd_exposed, sd_unexposed)
    fit <- lm(y ~ x + z, data = d)
    res[[r]] <- c(estimate = coef(fit)[["x"]],
                  se_model = sqrt(vcov(fit)["x", "x"]),
                  se_hc0   = sqrt(vcovHC(fit, type = "HC0")["x", "x"]),
                  se_hc1   = sqrt(vcovHC(fit, type = "HC1")["x", "x"]),
                  se_hc3   = sqrt(vcovHC(fit, type = "HC3")["x", "x"]))
  }
  as.data.frame(do.call(rbind, res))
}

## ---- scenarios (Step 2, provided) -----------------------------------------
t0 <- Sys.time()
sim_homo    <- simulate(R = 2000, n = 300, sd_exposed = 1, sd_unexposed = 1)
sim_hetero  <- simulate(R = 2000, n = 300, sd_exposed = 2, sd_unexposed = 1)
sim_reverse <- simulate(R = 2000, n = 300, sd_exposed = 1, sd_unexposed = 2)
sim_small   <- simulate(R = 2000, n = 80,  sd_exposed = 2, sd_unexposed = 1)
cat("four scenarios took", round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "seconds\n")

head(sim_hetero, 3)
scen <- rbind(homoscedastic           = summarise_sim(sim_homo),
              exposed_more_variable   = summarise_sim(sim_hetero),
              unexposed_more_variable = summarise_sim(sim_reverse),
              exposed_more_var_n80    = summarise_sim(sim_small))
print(t(scen))
cat("\nkey-only: ratio mean_se_model / sd_estimate:",
    round(scen[, "mean_se_model"] / scen[, "sd_estimate"], 3), "\n")
cat("key-only: ratio mean_se_hc3 / sd_estimate:",
    round(scen[, "mean_se_hc3"] / scen[, "sd_estimate"], 3), "\n")
cat("key-only: implied coverage if SE is 0.70 of truth: P(|Z| < 1.96*0.70) =",
    round(2 * pnorm(1.96 * 0.70) - 1, 3), "\n")
cat("key-only: min/max exposed in the n=80 samples:",
    {set.seed(785); range(replicate(2000, sum(make_data(80)$x)))}, "\n\n")

## ---- fig-sampling (Step 2, provided) --------------------------------------
cat("Step 2 — figure: sampling distribution in the heteroscedastic world (saved to solutions/fig_check_sampling.png)\n")
fig_sampling <- ggplot(sim_hetero, aes(x = estimate)) +
  geom_histogram(aes(y = after_stat(density)), bins = 60, fill = "grey85", color = "grey60") +
  stat_function(fun = dnorm, aes(color = "SD of the 2,000 estimates"),
                args = list(mean = mean(sim_hetero$estimate), sd = sd(sim_hetero$estimate)),
                linewidth = 1) +
  stat_function(fun = dnorm, aes(color = "Mean model-based SE"),
                args = list(mean = mean(sim_hetero$estimate), sd = mean(sim_hetero$se_model)),
                linewidth = 1, linetype = "dashed") +
  stat_function(fun = dnorm, aes(color = "Mean HC3 SE"),
                args = list(mean = mean(sim_hetero$estimate), sd = mean(sim_hetero$se_hc3)),
                linewidth = 1, linetype = "dotted") +
  geom_vline(xintercept = 2, color = "grey30") +
  scale_color_manual(values = c("SD of the 2,000 estimates" = "#0072B2",
                                "Mean model-based SE" = "#D55E00",
                                "Mean HC3 SE" = "#009E73")) +
  labs(x = "Estimated exposure coefficient (truth = 2)", y = "Density", color = NULL) +
  theme_classic() + theme(legend.position = "bottom")
ggsave("solutions/fig_check_sampling.png", fig_sampling, width = 6, height = 4, dpi = 150)
cat("\n")

## ---- boot-by-hand (Step 3, TODO 3a) --------------------------------------
cat("Step 3 — the bootstrap by hand on the Step 1 sample:\n")
set.seed(2026)
B <- 1000
b_star <- numeric(B)
for (b in 1:B) {
  # TODO (3a) completed: n row numbers drawn with replacement
  idx <- sample(nrow(dat), replace = TRUE)
  b_star[b] <- coef(lm(y ~ x + z, data = dat[idx, ]))[["x"]]
}
cat("first resample's distinct rows (key-only, re-drawn):",
    {set.seed(2026); length(unique(sample(nrow(dat), replace = TRUE)))}, "of 300  # expect ~ 63%\n")
cat("bootstrap SD of the replicates:", round(sd(b_star), 4), "\n")
cat("for comparison: model", round(se_tab["model"], 4), " HC0", round(se_tab["HC0"], 4), " HC3", round(se_tab["HC3"], 4), "\n")
cat("mean of replicates", round(mean(b_star), 4), " vs estimate", round(coef(fit)[["x"]], 4),
    " (bias", round(mean(b_star) - coef(fit)[["x"]], 4), ")\n")
cat("normal interval, by hand:", round(coef(fit)[["x"]] + c(-1, 1) * 1.96 * sd(b_star), 4), "\n")
cat("percentile interval, by hand:", round(quantile(b_star, c(.025, .975)), 4), "\n")
cat("Wald, model-based:", round(coef(fit)[["x"]] + c(-1, 1) * 1.96 * se_tab["model"], 4), "\n")
cat("Wald, HC3:        ", round(coef(fit)[["x"]] + c(-1, 1) * 1.96 * se_tab["HC3"], 4), "\n\n")

## ---- boot-package (Step 3, provided) --------------------------------------
cat("Step 3 — the boot package:\n")
boot_stat <- function(data, index) {
  coef(lm(y ~ x + z, data = data[index, ]))[["x"]]
}
set.seed(2026)
boot_res <- boot(data = dat, statistic = boot_stat, R = 1000)
print(boot_res)
print(boot.ci(boot_res, type = c("norm", "perc", "bca")))
cat("\n")

## ---- boot-sim (Step 3, provided) ------------------------------------------
cat("Step 3 — the bootstrap inside the simulation:\n")
fast_ols <- function(X, y) solve(crossprod(X), crossprod(X, y))   # (X'X)^-1 X'y, Week 4

simulate_boot <- function(R, n, B, sd_exposed = 2, sd_unexposed = 1, seed = 785) {
  set.seed(seed)
  res <- vector("list", R)
  for (r in 1:R) {
    d <- make_data(n, sd_exposed, sd_unexposed)
    X <- cbind(1, d$x, d$z)
    b_hat  <- fast_ols(X, d$y)[2]
    b_star <- numeric(B)
    for (k in 1:B) {
      idx <- sample(n, replace = TRUE)
      b_star[k] <- fast_ols(X[idx, ], d$y[idx])[2]
    }
    fit <- lm(y ~ x + z, data = d)
    res[[r]] <- c(estimate   = b_hat,
                  se_model   = sqrt(vcov(fit)["x", "x"]),
                  se_hc3     = sqrt(vcovHC(fit, type = "HC3")["x", "x"]),
                  se_boot    = sd(b_star),
                  perc_lower = quantile(b_star, 0.025, names = FALSE),
                  perc_upper = quantile(b_star, 0.975, names = FALSE))
  }
  as.data.frame(do.call(rbind, res))
}

t0 <- Sys.time()
sim_boot <- simulate_boot(R = 500, n = 300, B = 200)
cat("500 samples x 200 resamples took", round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "seconds\n")
print(summarise_sim(sim_boot))
cat("percentile-interval coverage:", round(mean(sim_boot$perc_lower <= 2 & 2 <= sim_boot$perc_upper), 3), "\n")
cat("key-only: MC standard error of a coverage estimate at R = 500:", round(sqrt(.95 * .05 / 500), 3),
    "; at R = 2000:", round(sqrt(.95 * .05 / 2000), 3), "\n\n")

## ---- bonus-poisson (Bonus, provided) --------------------------------------
cat("Bonus — Lab 5's question by simulation (Poisson model for a binary outcome):\n")
make_binary <- function(n, risk_unexposed, rr = 1.3) {
  z  <- rnorm(n)
  x  <- rbinom(n, 1, expit(-0.85 + 0.5 * z))               # about 30% exposed
  mu <- pmin(risk_unexposed * rr^x * exp(0.2 * z), 0.98)   # a log-linear risk; RR = 1.3
  y  <- rbinom(n, 1, mu)
  data.frame(y, x, z)
}
simulate_poisson <- function(R, n, risk_unexposed, seed = 785) {
  set.seed(seed)
  res <- vector("list", R)
  for (r in 1:R) {
    d   <- make_binary(n, risk_unexposed)
    fit <- glm(y ~ x + z, family = poisson(link = "log"), data = d)
    res[[r]] <- c(estimate  = coef(fit)[["x"]],
                  se_model  = sqrt(vcov(fit)["x", "x"]),
                  se_robust = sqrt(vcovHC(fit, type = "HC0")["x", "x"]),
                  mean_risk = mean(d$y))
  }
  as.data.frame(do.call(rbind, res))
}
t0 <- Sys.time()
pois_common <- simulate_poisson(R = 1000, n = 500, risk_unexposed = 0.5)
pois_rare   <- simulate_poisson(R = 1000, n = 500, risk_unexposed = 0.1)
cat("two scenarios took", round(as.numeric(difftime(Sys.time(), t0, units = "secs")), 1), "seconds\n")
pois_tab <- rbind(risk_about_0.55 = summarise_sim(pois_common, truth = log(1.3)),
                  risk_about_0.11 = summarise_sim(pois_rare,   truth = log(1.3)))
print(t(pois_tab))
cat("mean observed risk:", round(c(mean(pois_common$mean_risk), mean(pois_rare$mean_risk)), 3), "\n")
cat("key-only: 1/sqrt(1 - mu) at those risks:",
    round(1 / sqrt(1 - c(mean(pois_common$mean_risk), mean(pois_rare$mean_risk))), 3),
    " vs mean_se_model / sd_estimate:", round(pois_tab[, "mean_se_model"] / pois_tab[, "sd_estimate"], 3), "\n")
cat("\nDone.\n")
