# Lab 7 — Fit a Partially Linear Model: solution script
# The lab.qmd chunk code in chunk order, with the three TODOs (1a, 2a, 3a)
# completed. Run from the lab root (labs/lab7/):
#   Rscript solutions/solution.R
# Reads data/nhefs.csv (the NHEFS file shipped with the lab; also at
# https://miguelhernan.org/s/nhefs.csv). Prints every checkpoint in the
# handout plus the "key-only" extras the answer key quotes (tail
# linearity, a second contrast, the omitted-variable delta, per-fold
# weights, the no-cross-fitting comparison, the common TODO slips, and the
# median-over-fold-draws recipe). Writes one file,
# solutions/fig_check_curves.png (the Step 1 figure, for eyeballing).
# About ten seconds in all.
# Every random step is seeded (2026 for the fold draw and the super
# learners; 1 and 2 for the two extra fold draws), so the numbers
# reproduce exactly under R's default RNG.

t_start <- Sys.time()

## ---- setup ------------------------------------------------------------
pacman::p_load(tidyverse, splines, SuperLearner, gam, earth, sandwich, lmtest)

nhefs <- read_csv("data/nhefs.csv", show_col_types = FALSE) |>
  filter(!is.na(wt82_71)) |>
  select(wt82_71, qsmk, age, sex, race, smokeintensity, smokeyrs, wt71)

cat("setup: dim(nhefs) =", dim(nhefs), "  # 1,566 rows, 8 columns\n\n")

## ---- age-bands (Step 1, provided) -------------------------------------
cat("Step 1 — mean weight change in five-year age bands:\n")
print(as.data.frame(
  nhefs |>
    mutate(age_band = cut(age, breaks = seq(25, 75, by = 5), include.lowest = TRUE)) |>
    group_by(age_band) |>
    summarise(n = n(), mean_change = round(mean(wt82_71), 2))))
cat("\n")

## ---- three-splines (Step 1, provided) ---------------------------------
cat("Step 1 — the same spline, set three ways:\n")
fit_lin <- lm(wt82_71 ~ age, data = nhefs)                # the reference
fit_ns3 <- lm(wt82_71 ~ ns(age, df = 3), data = nhefs)    # 2 interior knots, at the tertiles
fit_ns5 <- lm(wt82_71 ~ ns(age, df = 5), data = nhefs)    # 4 interior knots, at the quintiles
fit_kn  <- lm(wt82_71 ~ ns(age, knots = c(45, 60)), data = nhefs)   # knots we chose

cat("knots, df = 3:", attr(ns(nhefs$age, df = 3), "knots"), "\n")
cat("knots, df = 5:", attr(ns(nhefs$age, df = 5), "knots"), "\n")
cat("basis, df = 3, first three rows:\n")
print(round(head(ns(nhefs$age, df = 3), 3), 4))
cat("coef(fit_ns3):\n")
print(round(coef(fit_ns3), 2))
print(AIC(fit_lin, fit_ns3, fit_ns5, fit_kn))

cat("key-only: columns in the basis: df 3 ->", ncol(ns(nhefs$age, df = 3)),
    " df 5 ->", ncol(ns(nhefs$age, df = 5)),
    " knots 45, 60 ->", ncol(ns(nhefs$age, knots = c(45, 60))),
    "  # interior knots = df - 1\n")
cat("key-only: coef(fit_kn):", round(coef(fit_kn), 2),
    "  # same df as fit_ns3, different columns, different weights\n")
cat("key-only: boundary knots (the range of age):",
    attr(ns(nhefs$age, df = 3), "Boundary.knots"), "\n")
# linear tails: the second differences of a natural spline's predictions
# beyond its boundary knots are zero
tail_pred <- predict(fit_ns3, newdata = data.frame(age = 74:90))
mid_pred  <- predict(fit_ns3, newdata = data.frame(age = 40:56))
cat("key-only: max |second difference| of the df-3 curve over ages 74-90:",
    signif(max(abs(diff(tail_pred, differences = 2))), 2), "  # a straight line\n")
cat("key-only: the same between the knots (ages 40-56):",
    signif(max(abs(diff(mid_pred, differences = 2))), 2), "  # curved\n\n")

## ---- curves (Step 1, provided) ----------------------------------------
cat("Step 1 — the curves and their HC3 bands (figure saved to solutions/fig_check_curves.png):\n")
X_at <- function(fit, newdata) model.matrix(delete.response(terms(fit)), data = newdata)

grid <- data.frame(age = 25:74)

curve_of <- function(fit, label) {
  X    <- X_at(fit, grid)
  V    <- vcovHC(fit, type = "HC3")             # Week 7's sandwich
  yhat <- as.vector(X %*% coef(fit))
  se   <- sqrt(diag(X %*% V %*% t(X)))
  tibble(fit = label, age = grid$age, yhat, lower = yhat - 1.96 * se, upper = yhat + 1.96 * se)
}

curves <- bind_rows(curve_of(fit_lin, "linear"),
                    curve_of(fit_ns3, "ns, df = 3"),
                    curve_of(fit_ns5, "ns, df = 5"),
                    curve_of(fit_kn,  "ns, knots at 45 and 60")) |>
  mutate(fit = factor(fit, levels = unique(fit)))

knots <- tibble(fit  = factor(c(rep("ns, df = 3", 2), rep("ns, df = 5", 4),
                                rep("ns, knots at 45 and 60", 2)), levels = levels(curves$fit)),
                knot = c(attr(ns(nhefs$age, df = 3), "knots"),
                         attr(ns(nhefs$age, df = 5), "knots"), 45, 60))

p_curves <- ggplot() +
  geom_point(data = nhefs, aes(age, wt82_71), colour = "grey60", alpha = .2, size = .6) +
  geom_vline(data = knots, aes(xintercept = knot), linetype = "dotted") +
  geom_ribbon(data = curves, aes(age, ymin = lower, ymax = upper), fill = "#D55E00", alpha = .25) +
  geom_line(data = curves, aes(age, yhat), colour = "#D55E00", linewidth = 1) +
  facet_wrap(~ fit) +
  coord_cartesian(ylim = c(-20, 20)) +      # 51 of the 1,566 changes lie beyond 20 kg
  labs(x = "Age in 1971 (years)", y = "Weight change, 1971 to 1982 (kg)") +
  theme_classic()
ggsave("solutions/fig_check_curves.png", p_curves, width = 7, height = 5, dpi = 150)

cat("key-only: changes beyond +/- 20 kg (off the panel):", sum(abs(nhefs$wt82_71) > 20), "\n")
bands <- curves |>
  filter(age %in% c(25, 50, 74)) |>
  mutate(yhat = round(yhat, 2), half_width = round((upper - lower) / 2, 2)) |>
  select(fit, age, yhat, half_width) |>
  pivot_wider(names_from = age, values_from = c(yhat, half_width))
cat("key-only: fitted value and HC3 half-width (1.96 se) at ages 25, 50, 74:\n")
print(as.data.frame(bands))
y_of <- function(label) curves$yhat[curves$fit == label]
cat("key-only: max |curve - curve| over ages 25-74 (kg): df3 vs knots",
    round(max(abs(y_of("ns, df = 3") - y_of("ns, knots at 45 and 60"))), 2),
    "; df3 vs df5", round(max(abs(y_of("ns, df = 3") - y_of("ns, df = 5"))), 2),
    "; linear vs df3", round(max(abs(y_of("linear") - y_of("ns, df = 3"))), 2), "\n\n")

## ---- contrast (Step 1, TODO 1a) ---------------------------------------
cat("Step 1 — the contrast 65 against 40 (TODO 1a completed):\n")
contrast_65_40 <- function(fit) {
  X    <- X_at(fit, data.frame(age = c(65, 40)))
  cvec <- X[1, ] - X[2, ]
  V    <- vcovHC(fit, type = "HC3")
  # TODO (1a) completed: the contrast c'beta, and its standard error sqrt(c'Vc)
  c(estimate = sum(cvec * coef(fit)),
    se = sqrt(as.numeric(t(cvec) %*% V %*% cvec)))
}

print(round(rbind(linear = contrast_65_40(fit_lin),
                  ns_df3 = contrast_65_40(fit_ns3),
                  ns_df5 = contrast_65_40(fit_ns5),
                  knots  = contrast_65_40(fit_kn)), 2))
cat("check, a difference of two predictions (df 3):",
    round(diff(predict(fit_ns3, newdata = data.frame(age = c(40, 65)))), 5), "\n")

# key-only: the same machinery at other ages, and with the model-based V
contrast_at <- function(fit, a1, a0, V = vcovHC(fit, type = "HC3")) {
  X    <- X_at(fit, data.frame(age = c(a1, a0)))
  cvec <- X[1, ] - X[2, ]
  c(estimate = sum(cvec * coef(fit)), se = sqrt(as.numeric(t(cvec) %*% V %*% cvec)))
}
fits4 <- list(linear = fit_lin, ns_df3 = fit_ns3, ns_df5 = fit_ns5, knots = fit_kn)
cat("key-only: 65 vs 40 with the model-based vcov(fit) in place of HC3:\n")
print(round(t(sapply(fits4, function(f) contrast_at(f, 65, 40, V = vcov(f)))), 2))
cat("key-only: 40 vs 25, the flat stretch (HC3):\n")
print(round(t(sapply(fits4, contrast_at, a1 = 40, a0 = 25)), 2))
cat("key-only: 74 vs 60, the steep end (HC3):\n")
print(round(t(sapply(fits4, contrast_at, a1 = 74, a0 = 60)), 2))
cat("\n")

## ---- nuisance-spline (Step 1, provided) --------------------------------
cat("Step 1 — the spline as a nuisance term:\n")
fit_adj_lin <- lm(wt82_71 ~ qsmk + age + sex + race + smokeintensity + smokeyrs + wt71,
                  data = nhefs)
fit_adj_ns  <- lm(wt82_71 ~ qsmk + ns(age, df = 3) + sex + race + ns(smokeintensity, df = 3) +
                    ns(smokeyrs, df = 3) + ns(wt71, df = 3), data = nhefs)

hc3 <- function(fit, term) coeftest(fit, vcov = vcovHC(fit, type = "HC3"))[term, 1:2]
print(round(rbind(linear_confounders = hc3(fit_adj_lin, "qsmk"),
                  spline_confounders = hc3(fit_adj_ns,  "qsmk")), 3))

# key-only: does the bend matter for the outcome, and is it correlated with the exposure?
cat("key-only: AIC, linear vs spline adjustment:", round(AIC(fit_adj_lin), 1), round(AIC(fit_adj_ns), 1), "\n")
a_out <- anova(fit_adj_lin, fit_adj_ns)
cat("key-only: F-test of the 8 extra spline columns in the OUTCOME model: F =",
    round(a_out$F[2], 2), " p =", signif(a_out[["Pr(>F)"]][2], 2), "\n")
ps_lin <- lm(qsmk ~ age + sex + race + smokeintensity + smokeyrs + wt71, data = nhefs)
ps_ns  <- lm(qsmk ~ ns(age, df = 3) + sex + race + ns(smokeintensity, df = 3) +
               ns(smokeyrs, df = 3) + ns(wt71, df = 3), data = nhefs)
a_exp <- anova(ps_lin, ps_ns)
cat("key-only: the same 8 columns in a linear model of the EXPOSURE on W: F =",
    round(a_exp$F[2], 2), " p =", signif(a_exp[["Pr(>F)"]][2], 2),
    "; R2", round(summary(ps_lin)$r.squared, 4), "->", round(summary(ps_ns)$r.squared, 4), "\n")
# the notes' delta: the leftover g(W) - gamma'W moves into whatever it is
# correlated with. Regress the spline fit's nuisance part on qsmk and the
# linear W; the qsmk coefficient is exactly the gap between the two models.
g_hat <- fitted(fit_adj_ns) - coef(fit_adj_ns)[["qsmk"]] * nhefs$qsmk
delta <- coef(lm(g_hat ~ qsmk + age + sex + race + smokeintensity + smokeyrs + wt71,
                 data = nhefs))[["qsmk"]]
cat("key-only: delta =", round(delta, 4), " vs (linear - spline) qsmk coefficient =",
    round(coef(fit_adj_lin)[["qsmk"]] - coef(fit_adj_ns)[["qsmk"]], 4), "  # identical\n")
cat("key-only: mean age by qsmk:", round(tapply(nhefs$age, nhefs$qsmk, mean), 1),
    "; share who quit by age band:\n")
print(round(tapply(nhefs$qsmk, cut(nhefs$age, c(25, 35, 45, 55, 65, 75), include.lowest = TRUE), mean), 3))
cat("\n")

## ---- y-a-w (Step 2, provided) ------------------------------------------
cat("Step 2 — Y, A, W:\n")
Y <- nhefs$wt82_71
A <- nhefs$qsmk
W <- nhefs |> select(age, sex, race, smokeintensity, smokeyrs, wt71) |> as.data.frame()
n <- nrow(W)
print(c(n = n, quit = sum(A), mean_change = round(mean(Y), 2)))
cat("key-only: var(Y) =", round(var(Y), 2), " sd(Y) =", round(sd(Y), 2),
    "  # the risk SL.mean aims at; var(A) =", round(var(A), 4), "\n\n")

## ---- library (Step 2, provided) ----------------------------------------
gam_df <- create.Learner("SL.gam", tune = list(deg.gam = c(2, 3, 5)))
lib <- c("SL.mean", "SL.glm", gam_df$names, "SL.earth")
cat("library:", lib, "  # SL.gam_1, _2, _3 are df 2, 3, 5\n\n")

## ---- outcome-sl (Step 2, provided) -------------------------------------
cat("Step 2 — the outcome model, cross-fitted (K = 5, seed 2026):\n")
K <- 5
set.seed(2026)
folds <- split(sample(1:n), rep(1:K, length.out = n))
inner <- rep(list(list(V = 5)), K)      # the inner 5-fold CV, one entry per outer fold

set.seed(2026)
cv_y <- CV.SuperLearner(Y = Y, X = W, family = gaussian(),
                        SL.library = lib, method = "method.NNLS",
                        cvControl = list(V = K, validRows = folds),
                        innerCvControl = inner)

print(summary(cv_y))
cat("weights, averaged over the K outer fits:\n")
print(round(colMeans(coef(cv_y)), 3))
cat("key-only: fold sizes:", lengths(folds), "\n")
cat("key-only: weights by outer fold:\n")
print(round(coef(cv_y), 3))
cat("key-only: the discrete super learner's pick, by fold:", unlist(cv_y$whichDiscreteSL), "\n")
cat("key-only: out-of-fold MSE of the super learner", round(mean((Y - cv_y$SL.predict)^2), 2),
    "= 1 -", round(1 - mean((Y - cv_y$SL.predict)^2) / var(Y), 3), "of var(Y)\n\n")

## ---- ps-sl (Step 2, TODO 2a) --------------------------------------------
cat("Step 2 — the propensity score on the same folds (TODO 2a completed):\n")
set.seed(2026)
# TODO (2a) completed: the binomial family, and the SAME fold assignment as the outcome model
cv_a <- CV.SuperLearner(Y = A, X = W, family = binomial(),
                        SL.library = lib, method = "method.NNLS",
                        cvControl = list(V = K, validRows = folds),
                        innerCvControl = inner)

print(summary(cv_a))
print(round(colMeans(coef(cv_a)), 3))

ps <- cv_a$SL.predict               # out-of-fold P(A = 1 | W), in row order
print(round(do.call(rbind, tapply(ps, A, quantile, c(0, .05, .5, .95, 1))), 3))

cat("key-only: weights by outer fold:\n")
print(round(coef(cv_a), 3))
cat("key-only: the discrete super learner's pick, by fold:", unlist(cv_a$whichDiscreteSL), "\n")
cat("key-only: propensity scores below 0.10:", sum(ps < 0.10), " above 0.60:", sum(ps > 0.60),
    " above 0.90:", sum(ps > 0.90), " of", n, "\n")
cat("key-only: mean PS by group:", round(tapply(ps, A, mean), 3),
    "; overall", round(mean(ps), 3), " vs share who quit", round(mean(A), 3), "\n")
# a TODO 2a slip: the gaussian family on a binary exposure
set.seed(2026)
cv_a_gauss <- CV.SuperLearner(Y = A, X = W, family = gaussian(),
                              SL.library = lib, method = "method.NNLS",
                              cvControl = list(V = K, validRows = folds),
                              innerCvControl = inner)
cat("key-only: with family = gaussian() by mistake: SL risk", round(summary(cv_a_gauss)$Table$Ave[1], 4),
    "; PS range", round(range(cv_a_gauss$SL.predict), 3),
    "; R-on-R slope", round(coef(lm(I(Y - cv_y$SL.predict) ~ -1 + I(A - cv_a_gauss$SL.predict)))[[1]], 3), "\n\n")

## ---- ror (Step 3, TODO 3a) ---------------------------------------------
cat("Step 3 — residual-on-residual regression (TODO 3a completed):\n")
# TODO (3a) completed: each variable minus its cross-fitted prediction, then the slope through the origin
y_til <- Y - cv_y$SL.predict        # the outcome with E[Y | W] removed
a_til <- A - ps                     # the exposure with E[A | W] removed
print(round(c(mean_y_til = mean(y_til), mean_a_til = mean(a_til)), 4))

ror <- lm(y_til ~ -1 + a_til)
print(coeftest(ror, vcov = vcovHC(ror, type = "HC3")))

cat("by hand, sum(a_til * y_til) / sum(a_til^2):", sum(a_til * y_til) / sum(a_til^2), "\n")

print(round(rbind(linear_confounders = hc3(fit_adj_lin, "qsmk"),
                  spline_confounders = hc3(fit_adj_ns,  "qsmk"),
                  super_learner_ror  = hc3(ror, "a_til")), 3))

est <- coef(ror)[[1]]
se  <- sqrt(vcovHC(ror, type = "HC3")[1, 1])
cat("key-only: model-based SE of ror (Robinson's):", round(summary(ror)$coefficients[1, 2], 4),
    " vs HC3", round(se, 4), "\n")
cat("key-only: 95% Wald interval:", round(est + c(-1, 1) * 1.96 * se, 2), "\n")
cat("key-only: sd of the out-of-fold residuals: y_til", round(sd(y_til), 3), " a_til", round(sd(a_til), 4),
    "; cor(a_til, y_til)", round(cor(a_til, y_til), 4), "\n")
cat("key-only: with an intercept by mistake, lm(y_til ~ a_til):", round(coef(lm(y_til ~ a_til)), 4),
    "  # the slope barely moves\n")
cat("key-only: residuals reversed by mistake, lm(a_til ~ -1 + y_til):",
    round(coef(lm(a_til ~ -1 + y_til))[[1]], 4), "  # a different quantity\n")

# key-only: WITHOUT cross-fitting: each super learner fit once to all the
# data, and its in-sample predictions used as the nuisance values
set.seed(2026)
sl_y <- SuperLearner(Y = Y, X = W, family = gaussian(), SL.library = lib,
                     method = "method.NNLS", cvControl = list(V = 5))
set.seed(2026)
sl_a <- SuperLearner(Y = A, X = W, family = binomial(), SL.library = lib,
                     method = "method.NNLS", cvControl = list(V = 5))
y_in <- Y - as.vector(sl_y$SL.predict)
a_in <- A - as.vector(sl_a$SL.predict)
ror_in <- lm(y_in ~ -1 + a_in)
cat("key-only: WITHOUT cross-fitting: sd(y_in)", round(sd(y_in), 3), " sd(a_in)", round(sd(a_in), 4),
    "; slope", round(coef(ror_in)[[1]], 3), " HC3", round(sqrt(vcovHC(ror_in, type = "HC3")[1, 1]), 3), "\n")
cat("key-only: in-sample MSE of the outcome super learner", round(mean(y_in^2), 2),
    " vs out of fold", round(mean(y_til^2), 2), "\n")
cat("key-only: full-data weights, outcome: "); cat(round(sl_y$coef, 3), "\n")
cat("key-only: full-data weights, exposure:"); cat(round(sl_a$coef, 3), "\n\n")

## ---- seeds (optional, provided; this version also returns the HC3 SE) ----
cat("Step 3 — two more fold assignments (about 15 seconds):\n")
ror_with_seed <- function(seed) {
  set.seed(seed)
  f  <- split(sample(1:n), rep(1:K, length.out = n))
  cy <- CV.SuperLearner(Y = Y, X = W, family = gaussian(), SL.library = lib,
                        cvControl = list(V = K, validRows = f), innerCvControl = inner)
  ca <- CV.SuperLearner(Y = A, X = W, family = binomial(), SL.library = lib,
                        cvControl = list(V = K, validRows = f), innerCvControl = inner)
  r  <- lm(I(Y - cy$SL.predict) ~ -1 + I(A - ca$SL.predict))
  c(estimate = coef(r)[[1]], se_hc3 = sqrt(vcovHC(r, type = "HC3")[1, 1]))   # the handout returns the estimate only
}
seed_fits <- sapply(c(1, 2), ror_with_seed)
colnames(seed_fits) <- c("seed_1", "seed_2")
cat("estimates:", round(seed_fits["estimate", ], 3), "  # the handout's checkpoint: 3.358, 3.430\n")
cat("key-only: their HC3 SEs:", round(seed_fits["se_hc3", ], 3), "\n")

# key-only: Chernozhukov et al.'s (2018) median recipe over the three fold draws
ests <- c(seed_2026 = est, seed_fits["estimate", ])
ses  <- c(seed_2026 = se,  seed_fits["se_hc3", ])
med  <- median(ests)
cat("key-only: three fold draws: estimates", round(ests, 3), "; median", round(med, 3), "\n")
cat("key-only: adjusted SE, sqrt(median(se^2 + (est - median)^2)) =",
    round(sqrt(median(ses^2 + (ests - med)^2)), 4), " vs the single-draw SE", round(se, 4), "\n")
cat("key-only: SD of the three estimates", round(sd(ests), 3), "=", round(sd(ests) / se, 2), "of the HC3 SE\n")

cat("\nDone in", round(as.numeric(difftime(Sys.time(), t_start, units = "secs"))), "seconds.\n")
