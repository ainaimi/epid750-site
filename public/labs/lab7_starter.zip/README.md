# Lab 7 — Fit a Partially Linear Model

A lab about the *nuisance function*: one dataset (the NHEFS, 1,566
people with a weight recorded at both visits), one question (the effect
of quitting smoking on weight change from 1971 to 1982, adjusting for
age, sex, race, smoking intensity, years of smoking, and baseline
weight), and three ways of modelling the confounders beside one
parametric exposure coefficient.

- **Three natural splines** (Step 1): weight change against age with
  `ns()` at `df = 3` (knots placed by `ns()` at ages 36 and 50), at
  `df = 5` (32, 39, 47, 55), and at knots we place ourselves (45 and
  60); the fits read through predictions with HC3 bands and one
  contrast, 65 against 40 years of age: −3.73 kg (SE 0.40) from the
  straight line, −6.39 / −6.45 / −6.28 (0.63 / 0.71 / 0.63) from the
  three splines. Then the spline as a nuisance term: the `qsmk`
  coefficient is 3.34 (0.476) with every confounder linear and 3.43
  (0.473) with `df = 3` splines on the four continuous ones.
- **The super learner** (Step 2): a library of built-in learners
  (`SL.mean`, `SL.glm`, `SL.gam` at df 2, 3, and 5 through
  `create.Learner()`, `SL.earth`), fit with `CV.SuperLearner()` to the
  outcome and to the propensity score on one shared five-fold
  assignment (seed 2026). Cross-validated risks 56.42 and 0.1827; the
  df-2 GAM carries 0.59 and 0.62 of the weight; the out-of-fold
  propensity scores run from 0.09 to 0.69 in both exposure groups.
- **Residual-on-residual regression** (Step 3): the two out-of-fold
  residuals, a no-intercept `lm()`, and the HC3 sandwich: 3.38 kg
  (SE 0.470), reproduced by hand as the ratio of two sums; two other
  fold assignments give 3.36 and 3.43.

## Quick start

1. Open `lab7.Rproj` in RStudio.
2. The data ship with the lab: `data/nhefs.csv` is the NHEFS file
   distributed with Hernán and Robins, *Causal Inference: What If*
   (also at <https://miguelhernan.org/s/nhefs.csv>).
3. Packages: `pacman::p_load(tidyverse, splines, SuperLearner, gam,
   earth, sandwich, lmtest)` (`splines` ships with R; `sandwich` and
   `lmtest` were Labs 2 to 6; `SuperLearner`, `gam`, and `earth` are
   new and install on first use).
4. Open `lab.qmd` and work top to bottom. Three chunks contain `TODO`s
   (with `???` placeholders that error until fixed); everything else is
   provided, and much of the work is in the questions.
5. When the `TODO` chunks run, flip `eval: false` to `eval: true` in
   the YAML header and render to HTML. The whole document runs in well
   under a minute. The fold assignment is seeded, so the numbers in the
   checkpoints reproduce exactly.

Deliverables are **yours to keep** — the rendered HTML is not
submitted; keep it for exam preparation.

## Folder layout

```
lab.qmd        the lab document — start here
lab7.Rproj     RStudio project anchor
data/          nhefs.csv, the NHEFS data (see Data source)
```

## Data source

The National Health and Nutrition Examination Survey Data I
Epidemiologic Follow-up Study (NHEFS), as distributed with Hernán MA,
Robins JM, *Causal Inference: What If* (Chapman & Hall/CRC, 2020),
<https://miguelhernan.org/s/nhefs.csv>: public-use US government survey
data, redistributed freely for teaching through the book's website. The
lab follows the book's running example: cigarette smokers aged 25 to 74
at the 1971–75 baseline visit, with weight change measured at the 1982
follow-up.

## Readings the lab leans on

- The lecture notes *Flexible Regression: Splines and the Super
  Learner*, sections 3 to 5.
- Hernán & Robins, *Causal Inference: What If*, 2020 (the data and the
  question).
- van der Laan, Polley & Hubbard, *Stat Appl Genet Mol Biol* 2007 (the
  super learner, Step 2).
- Phillips et al., *Int J Epidemiol* 2023 (specifying a super learner,
  Step 2).
- Robinson, *Econometrica* 1988, and Chernozhukov et al., *Econometrics
  J* 2018 (residual-on-residual regression and cross-fitting, Step 3).
- Zivich & Breskin, *Epidemiology* 2021 (cross-fit estimators, Step 3).
