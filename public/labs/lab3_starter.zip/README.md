# Lab 3 — Three Questions

A short lab, and a different kind of lab: almost no new code. One
multivariable logistic regression is fit to the Lab 1 cohort (1,292 ICU
stays; early vasopressor initiation; in-hospital death) **before any
question is asked** — the way much published analysis actually begins —
and the lab then asks that single printout a **descriptive**, a
**predictive**, and a **causal** question in turn:

- **descriptive** (Lesko/Fox/Edwards): write a descriptimand anchored in
  person/place/time; the intercept-only model recovers the crude
  proportion (0.107); the printout's adjusted sex row (OR 1.34) answers
  a question nobody asked, next to the crude contrast (1.21) — and a
  lower AIC does not change which question it answers;
- **predictive** (Vansteelandt & Steen): write a predictimand —
  deployment population, prediction moment, available-at-that-moment
  inputs, loss; the largest coefficient in the table adds 0.002 of AUC
  (0.7246 → 0.7225), and in-sample calibration is a check that cannot
  fail;
- **causal** (Carlin & Moreno-Betancur; Lab 1's estimand): the exposure
  row (OR 1.54, CI 0.57–4.16) priced in two layers — identification
  (exchangeability, positivity = the 27 exposed, consistency) and model
  (constant conditional effect, functional form).

The takeaway: the coefficient table never changes. What changes, three
times, is the question — and with it the estimand, the parts of the
printout that matter, and the assumptions needed to read it.

## Quick start

1. Open `lab3.Rproj` in RStudio.
2. The lab reads your **Lab 1** output. If `labs/lab1/` sits next to
   this folder with its pipeline completed, nothing else is needed;
   otherwise use the copy of `analytic_dataset.csv` that ships in this
   starter package's `data/` folder (downloaded from the course site).
3. Packages: `pacman::p_load(tidyverse)` — nothing else.
4. Open `lab.qmd` and work top to bottom. Only two chunks contain
   `TODO`s (with `???` placeholders that error until fixed); most
   blanks in this lab are **sentences** — estimand templates and
   short-answer questions.
5. When the two `TODO` chunks run, flip `eval: false` to `eval: true`
   in the YAML header and render to HTML.

Deliverables are **yours to keep** — the rendered HTML is not
submitted; keep it for exam preparation.

## Folder layout

```
lab.qmd        the lab document — start here
lab3.Rproj     RStudio project anchor
data/          a copy of Lab 1's analytic_dataset.csv (plus its codebook)
               for anyone without a completed Lab 1
```

## Data source

The cohort is the Lab 1 analytic dataset, derived from the eICU
Collaborative Research Database Demo v2.0.1 (PhysioNet;
doi:10.13026/4mxk-na84; ODbL license) — see `labs/lab1/README.md` for
full provenance and citation.

## Readings the lab leans on

- Carlin & Moreno-Betancur, *Stat Med* 2025 (and the Vansteelandt &
  Steen commentary in the same PDF) — the three-questions framework.
- Lesko, Fox & Edwards, *Am J Epidemiol* 2022 — the descriptive
  framework used in Step 1.
