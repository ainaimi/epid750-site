# Lab 1 — Constructing an Analytic Dataset for a Target Trial Emulation

Build the analytic dataset for an emulation of a target trial of **early
vasopressor initiation vs. no early initiation** after a first hypotensive
episode, among adult ICU patients, with in-hospital death as the outcome —
using the open **eICU Collaborative Research Database Demo**. No causal effect
is estimated in this lab; the deliverable is a documented, quality-checked
dataset whose every column corresponds to a component of the target-trial
protocol (TARGET items 6a–6f).

## Quick start

1. Open `lab1.Rproj` in RStudio (this sets the working directory correctly).
2. Run `R/00_download_data.R` once (~22 MB from PhysioNet into `data/raw/`).
   If PhysioNet is slow or unreachable, download the lab data zip from CANVAS
   and unzip its four files into `data/raw/`, then re-run `00` to verify.
3. Open `lab.qmd` and follow it; it walks you through completing and running
   `R/01_…` → `R/05_…` in order.

## Folder layout

```
lab.qmd                    the lab document — start here after setup
R/
  00_download_data.R       fetch + verify the raw tables (fully provided)
  01_eligibility.R         TARGET 6a  -> data/derived/01_eligible.csv
  02_exposure.R            TARGET 6b-c -> data/derived/02_exposure.csv
  03_outcome.R             TARGET 6d-e -> data/derived/03_outcome.csv
  04_analytic_dataset.R    assemble   -> data/derived/analytic_dataset.csv
  05_qc.R                  quality-control report (console output)
data/
  raw/                     eICU demo tables (.csv.gz) — not tracked in git
  derived/                 pipeline outputs — not tracked in git
```

## Data source, citation, license

Raw data are four tables (`patient`, `vitalPeriodic`, `vitalAperiodic`,
`infusiondrug`) from the eICU Collaborative Research Database **Demo**
v2.0.1 — an openly available subsample (2,520 ICU stays) of the full
credentialed-access database. All time variables are integer minutes ("offsets")
relative to ICU unit admission.

> Pollard T, Johnson A, Raffa J, Celi LA, Badawi O, Mark R. *eICU
> Collaborative Research Database Demo* (version 2.0.1). PhysioNet, 2021.
> https://doi.org/10.13026/4mxk-na84

> Pollard TJ, Johnson AEW, Raffa JD, Celi LA, Mark RG, Badawi O. The eICU
> Collaborative Research Database, a freely available multi-center database
> for critical care research. *Sci Data*. 2018;5:180178.

License: Open Data Commons Open Database License v1.0 (ODbL). The demo may be
shared with attribution; the download script records file checksums from the
PhysioNet distribution.

**Documentation (codebook).** The official eICU-CRD documentation at
<https://eicu.mit.edu> serves as the codebook: per-table pages with
column-by-column definitions (e.g.
<https://eicu.mit.edu/eicutables/patient/>), tutorials for the vitals and
infusion tables, a glossary of ICU terms, and a browsable schema at
<https://mit-lcp.github.io/eicu-schema-spy/>. It documents the full
eICU-CRD; the demo is a subsample with identical structure. (Note: the
older `eicu-crd.mit.edu` links cited in some papers now redirect to the
new site's homepage.)
