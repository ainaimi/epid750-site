# ==================================================================
# 04_analytic_dataset.R — assemble the final analytic dataset
#
# (Fully provided.) One row per patient (= per eligible first ICU
# stay), with every column traceable to a protocol component:
#
#   patientunitstayid          identifier
#   time_zero_offset           6a  (eligibility moment / time zero)
#   landmark_offset            6d  (start of follow-up)
#   early_vasopressor          6b-c (strategy classification)
#   first_vasopressor_offset   6b-c (timing behind the classification)
#   hospital_death             6e  (primary binary outcome)
#   death_event, followup_days 6d-e (time-to-event outcome, later labs)
#   age, sex                   baseline covariates
#   baseline_map, baseline_hr  baseline covariates (at time zero)
#   baseline_map_source        measurement provenance (7a)
#
# Reads : data/derived/03_outcome.csv
# Writes: data/derived/analytic_dataset.csv
# ==================================================================

pacman::p_load(tidyverse)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

outcomes <- read_csv("data/derived/03_outcome.csv", show_col_types = FALSE)

analytic <- outcomes |>
  select(
    patientunitstayid,
    time_zero_offset, landmark_offset,
    early_vasopressor, first_vasopressor_offset,
    hospital_death, death_event, followup_days,
    age, sex, baseline_map, baseline_hr, baseline_map_source
  )

write_csv(analytic, "data/derived/analytic_dataset.csv")

message("Analytic dataset written: ", nrow(analytic), " rows, ",
        ncol(analytic), " columns")
glimpse(analytic)
