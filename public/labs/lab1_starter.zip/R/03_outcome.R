# ==================================================================
# 03_outcome.R — TARGET 6d–6e: follow-up, the landmark, and outcomes
#
# In the target trial, follow-up starts at assignment (= time zero)
# and ends at hospital discharge or in-hospital death. In our
# emulation, classification into a strategy uses the 60 minutes
# AFTER time zero — so starting follow-up AT time zero would define
# each person's group with information from their future (see
# lab.qmd, "Alignment"). This lab's fix is a 60-MINUTE LANDMARK:
# keep patients still alive and observable (in the ICU) at
# time zero + 60, and begin follow-up there.
#
# Reads : data/derived/02_exposure.csv
# Writes: data/derived/03_outcome.csv
#
# Complete  >>> TODO (3a) ... (3c).
# Checkpoint: 1,292 rows, 27 with early_vasopressor == 1.
# ==================================================================

pacman::p_load(tidyverse)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

exposure <- read_csv("data/derived/02_exposure.csv", show_col_types = FALSE)

# ---- Step 1: the landmark ----------------------------------------

## >>> TODO (3a) ----------------------------------------------------
## Create the landmark (60 minutes after time zero) and keep only
## the stays still IN THE ICU at that moment. "In the ICU at the
## landmark" does two jobs at once:
##   - ALIVE at the landmark (you cannot enter follow-up dead);
##   - OBSERVABLE through the whole grace period (infusions are only
##     recorded while the patient is in the ICU — someone
##     transferred out at minute 40 has an incomplete classification
##     window, so "no initiation seen" would not mean "no
##     initiation").
## Which patient-table offset marks the end of the ICU stay?
## Replace the ???s.

landmarked <- exposure |>
  mutate(landmark_offset = time_zero_offset + ???) |>
  filter(??? >= landmark_offset)

## <<< --------------------------------------------------------------

message("At the landmark: ", nrow(landmarked),
        " stays  (expect 1,292; ",
        nrow(exposure) - nrow(landmarked),
        " excluded — expect 16)")

# ---- Step 2: the outcomes ----------------------------------------
# The primary outcome is in-hospital death, from the patient table's
# discharge status. A handful of stays have a BLANK status: code
# them NA — an unrecorded outcome is not a survivor.

## >>> TODO (3b) ----------------------------------------------------
## Code hospital_death: 1 if hospitaldischargestatus is "Expired",
## 0 if "Alive", NA otherwise. case_when()'s .default catches the
## blanks. Replace the ???s.

## >>> TODO (3c) ----------------------------------------------------
## Follow-up time for the time-to-event version of the outcome
## (retained for later labs): days from the START OF FOLLOW-UP to
## hospital discharge (dead or alive). Offsets are in minutes; 1440
## minutes = 1 day. THINK: which offset does follow-up start from in
## our emulation — time_zero_offset or landmark_offset? (lab.qmd Q6.)

outcomes <- landmarked |>
  mutate(
    hospital_death = case_when(
      hospitaldischargestatus == "Expired" ~ ???,
      hospitaldischargestatus == "Alive"   ~ ???,
      .default = NA_integer_
    ),
    death_event   = hospital_death,
    followup_days = (hospitaldischargeoffset - ???) / 1440
  )

## <<< --------------------------------------------------------------

# ---- Step 3: save ------------------------------------------------

write_csv(outcomes, "data/derived/03_outcome.csv")

message("Written data/derived/03_outcome.csv: ", nrow(outcomes),
        " rows; early initiators: ", sum(outcomes$early_vasopressor),
        "  (expect 1,292 and 27)")
