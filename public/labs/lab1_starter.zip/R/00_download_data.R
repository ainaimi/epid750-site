# ==================================================================
# 00_download_data.R — fetch the raw eICU demo tables for Lab 1
#
# Downloads the four tables this lab uses from PhysioNet (open access,
# ~22 MB total) into data/raw/, and verifies each file against its
# SHA-256 checksum from the PhysioNet distribution.
#
# This script is fully provided — nothing here to complete. Run it once.
# It is safe to re-run: files already present and intact are skipped.
#
# If PhysioNet is unreachable, download the lab data zip from CANVAS,
# unzip its four .csv.gz files into data/raw/, and re-run this script
# to verify the checksums.
#
# Source: eICU Collaborative Research Database Demo v2.0.1
#   Pollard et al., PhysioNet, 2021. doi:10.13026/4mxk-na84
#   License: ODbL v1.0
# ==================================================================

pacman::p_load(digest)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

base_url <- "https://physionet.org/files/eicu-crd-demo/2.0.1"

checksums <- c(
  "patient.csv.gz"        = "15e1eb52169828e3cfff3b67132a087298de4d0365bbb31bb294f6043bffd474",
  "vitalPeriodic.csv.gz"  = "04dc093a2e77cd4c52ac7f2a47a8356fbb7456c7f15deb20d5abb1ca4303231d",
  "vitalAperiodic.csv.gz" = "c294f46647990cb648b3ebfa589e83f330bdc0c2c922b5e8f23aa0ef99954635",
  "infusiondrug.csv.gz"   = "3b9f024d28682884a820763ac516ae68b247ebf17903fee4f38240c04886d527"
)

dir.create("data/raw",     recursive = TRUE, showWarnings = FALSE)
dir.create("data/derived", recursive = TRUE, showWarnings = FALSE)

# vitalPeriodic is ~19 MB; allow slow connections plenty of time
options(timeout = max(600, getOption("timeout")))

for (f in names(checksums)) {
  dest <- file.path("data", "raw", f)

  if (file.exists(dest) &&
      digest(file = dest, algo = "sha256") == checksums[[f]]) {
    message("ok (already present): ", f)
    next
  }

  message("downloading: ", f, " ...")
  download.file(file.path(base_url, f), destfile = dest,
                mode = "wb", quiet = TRUE)

  if (digest(file = dest, algo = "sha256") != checksums[[f]]) {
    stop("Checksum mismatch for ", f,
         " — delete data/raw/", f,
         " and re-run, or use the CANVAS copy of the data.")
  }
  message("ok (downloaded): ", f)
}

message("All four raw tables are ready in data/raw/.")
