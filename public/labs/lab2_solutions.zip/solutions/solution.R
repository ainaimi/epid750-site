# =====================================================================
# Lab 2 — The Case-Cohort Design: INSTRUCTOR SOLUTION
# ---------------------------------------------------------------------
# The lab chunk code with every TODO completed, in order, same seeds.
# Run from the lab root:  Rscript solutions/solution.R
#
# Structure:
#   Step 1  cohort truth, computed by hand (2x2, risks, rates)
#   Step 2  draw the case-cohort sample (q = 0.20, seed 13)
#   Step 3  SPLITTING UP THE PERSON-TIME (the weights) + design checks
#   Part A  time-to-event analyses (these need the split PT): weighted KM
#           and weighted Cox in the case-cohort sample, then the same
#           analyses in the original cohort
#   Part B  binary-outcome analyses (simple one-weight-per-person, no need for split PT):
#           weighted log-Poisson (RR) and linear (RD) in the case-cohort
#           sample, then the same models in the original cohort
#   Part C  ILLUSTRATIVE EXAMPLE: keep the person-time of cases not selected into the
#           subcohort -> the double-counting problem, shown on the
#           design checks, the KM, and the Cox
#   Then:   2,000-draw in-expectation loop; save step; q-dial
#
# Figure chunks are omitted (no TODOs); their numeric checkpoints
# (risk_at readouts) are reproduced below. All robust GLM SEs are HC3.
# =====================================================================

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab2 folder (open lab2.Rproj first, ",
       "or run: cd labs/lab2 && Rscript solutions/solution.R).")
}

## ---- setup ----------------------------------------------------------
pacman::p_load(tidyverse, survival, sandwich, lmtest)

## note: depending on where you put things on your computer, you may need
## to modify this code.

paths <- c("../lab1/data/derived/analytic_dataset.csv",  # Lab 1, completed in place
           "data/analytic_dataset.csv")                  # or the website copy
path <- paths[file.exists(paths)][1]
if (is.na(path)) {
  stop("analytic_dataset.csv not found. Complete Lab 1 first, or download ",
       "the dataset from CANVAS into labs/lab2/data/.")
}
lab1 <- read_csv(path, show_col_types = FALSE)
message("setup: nrow(lab1) = ", nrow(lab1), "   (expect 1292)")

## ---- cohort-2x2  [TODO 1a completed] --------------------------------
coh <- lab1 |> filter(!is.na(hospital_death))

n_coh <- nrow(coh)
a1 <- sum(coh$early_vasopressor == 1 & coh$hospital_death == 1)
b1 <- sum(coh$early_vasopressor == 1 & coh$hospital_death == 0)
a0 <- sum(coh$early_vasopressor == 0 & coh$hospital_death == 1)
b0 <- sum(coh$early_vasopressor == 0 & coh$hospital_death == 0)
print(c(n_coh = n_coh, a1 = a1, b1 = b1, a0 = a0, b0 = b0))

## ---- cohort-benchmarks  [TODO 1b, 1c completed] ---------------------
# Note: there are many ways to compute risks and rates, but we keep things
# simple here
R1 <- a1 / (a1 + b1)
R0 <- a0 / (a0 + b0)
rr_cohort <- R1 / R0
rd_cohort <- R1 - R0
print(round(c(R1 = R1, R0 = R0, RR = rr_cohort, RD = rd_cohort), 3))

pt1 <- sum(coh$followup_days[coh$early_vasopressor == 1])
pt0 <- sum(coh$followup_days[coh$early_vasopressor == 0])
rate1 <- a1 / pt1
rate0 <- a0 / pt0
print(round(c(pt1 = pt1, pt0 = pt0, total_pt = pt1 + pt0,
              rate1_per100pd = 100 * rate1, rate0_per100pd = 100 * rate0,
              rate_ratio = rate1 / rate0), 3))

## ---- draw-sample  [TODO 2a completed] -------------------------------
# There are many ways to draw a random sample from baseline. Here's one:
q <- 0.20
set.seed(13)
coh <- coh |>
  mutate(subc = rbinom(n(), 1, q) == 1)    # drawn using the rbinom function

coh |> 
  select(patientunitstayid, hospital_death, subc) |> 
  print(n = 100)

mean(coh$subc)

## note here we create a new sample called "samp" by selecting
## EITHER individuals whose "subc" varaible is "TRUE" OR if
## they experienced the outocme of interest.
##
## This gives us three types of people in the "samp" data frame:
## Type 1) non-events who were randomly sampled from the baseline data (i.e., subc = TRUE and hospital_death = 0)
## Type 2) events who were randomly sampled from the baseline data (i.e., subc = TRUE and hospital_death = 1)
## Type 3) events who were NOT sampled from the baseline data (i.e., subc = FALSE and hospital_death = 1)
samp <- coh |> filter(subc | hospital_death == 1)

samp |> 
  select(patientunitstayid, followup_days, hospital_death, subc) |> 
  print(n = 100)

print(c(n_subcohort   = sum(coh$subc),
        cases_inside  = sum(samp$hospital_death == 1 & samp$subc),
        cases_outside = sum(samp$hospital_death == 1 & !samp$subc),
        n_sample      = nrow(samp)))

## ---- Splitting up the Person-Time  [TODO 3a, 3b completed] ----------
## Note that each of the three types of people in the samp dataset needs to be
## handled differently when constructing the weights.
## Type 1 people all receive a weight of 1/q
## Type 2 people person time has to be split up:
##    - person-time from start to right before the event receives a weight of 1/q
##    - the event receives a weight of 1
## Type 3 people person time has to be split up:
##    - person-time from start to right before the event receives a weight of 0 (i.e., this person time is removed)
##    - the event receives a weight of 1
##
## Why the weights vary over time: a case's probability of being in the
## sample changes at their event. Before it, they could only enter via
## the subcohort (probability q); at the event, probability 1. Splitting
## the person-time lets each segment carry the right inverse-probability
## weight. (NB, this is not about time-varying exposures or covariates:
## the exposure is fixed at baseline. The split exists because the
## WEIGHT changes over time.)
##
## We encode the split in counting-process ("long") format: one row per
## person-time segment, (start, stop], with an event indicator and a
## weight. eps separates "right before the event" from the event itself;
## event times sit on a 1-minute grid (1/1440 of a day), so eps = 1e-4
## days (~9 seconds) slips below it.

eps <- 1e-4

cc <- rbind(
  # Type 1 — subcohort non-events: full follow-up at weight 1/q
  with(subset(samp, subc & hospital_death == 0),
       data.frame(id = patientunitstayid, a = early_vasopressor,
                  start = 0, stop = followup_days,
                  event = 0, w = 1/q)),
  # Type 2, pre-event segment — subcohort events: weight 1/q from start
  # to right before the event
  with(subset(samp, subc & hospital_death == 1),
       data.frame(id = patientunitstayid, a = early_vasopressor,
                  start = 0, stop = followup_days - eps,
                  event = 0, w = 1/q)),
  # Types 2 & 3, event segment — every case's event at weight 1
  # (Type 3's pre-event person-time gets weight 0: it has no row at all)
  with(subset(samp, hospital_death == 1),
       data.frame(id = patientunitstayid, a = early_vasopressor,
                  start = pmax(0, followup_days - eps),
                  stop = followup_days, event = 1, w = 1))
)

# rows per type: Type 1 = 231; Type 2 = 29 people x 2 rows = 58; Type 3 = 107
message("nrow(cc) = ", nrow(cc), "   (expect 231 + 58 + 107 = 396)")

tail(cc)

## ---- design-checks --------------------------------------------------
## Before estimating anything, check that the weighted split
## reconstructs the cohort: weighted person-time should APPROXIMATE the
## cohort total (it is an estimate built from a 20% sample); weighted
## events should equal 136 EXACTLY (every case is in, at weight 1).
print(c(cohort_pt   = sum(coh$followup_days),
        weighted_pt = sum(cc$w * (cc$stop - cc$start))))
message("weighted events = ", sum(cc$w[cc$event == 1]), "   (expect 136)")
message("weighted time-zero risk set = ", sum(cc$w[cc$start == 0]),
        "   (expect 1300)")

## =====================================================================
## PART A — TIME-TO-EVENT ANALYSES (these NEED the person-time split)
## ---------------------------------------------------------------------
## Kaplan-Meier and Cox are built on RISK SETS indexed by time, so the
## weight a person carries must be allowed to change over follow-up:
## 1/q while serving as comparison person-time, 1 at the event, and 0
## (no row) for the never-sampled comparison time of Type-3 cases. That
## is exactly what the split encodes.
## =====================================================================

## ---- A1: weighted KM and weighted Cox, case-cohort sample -----------
km_cc <- survfit(Surv(start, stop, event) ~ 1, data = cc, weights = w)

risk_at <- function(fit, t) 1 - summary(fit, times = t)$surv
message("case-cohort weighted KM, cumulative risk at 5 / 10 / 30 days:")
print(round(risk_at(km_cc, c(5, 10, 30)), 3))

# Weighted Cox: naive (model-based) SE, then robust clustered on the
# person, so a Type-2 person's two rows count as ONE individual
cox_cc_naive  <- coxph(Surv(start, stop, event) ~ a,
                       data = cc, weights = w, robust = FALSE)
cox_cc_robust <- coxph(Surv(start, stop, event) ~ a,
                       data = cc, weights = w, cluster = id)

## ---- A2: the same analyses in the original cohort -------------------
km_full <- survfit(Surv(followup_days, hospital_death) ~ 1, data = coh)
cox_full <- coxph(Surv(followup_days, hospital_death) ~ early_vasopressor,
                  data = coh)

message("KM side by side (cumulative risk at 5 / 10 / 30 days):")
print(round(rbind(full_cohort = risk_at(km_full, c(5, 10, 30)),
                  case_cohort = risk_at(km_cc, c(5, 10, 30))), 3))

message("Cox side by side:")
print(round(rbind(
  full_cohort  = c(loghr = coef(cox_full), se = sqrt(vcov(cox_full)[1, 1])),
  cc_naive_SE  = c(coef(cox_cc_naive),  sqrt(cox_cc_naive$var[1, 1])),
  cc_robust_SE = c(coef(cox_cc_robust), sqrt(cox_cc_robust$var[1, 1]))), 3))
message("(the case-cohort naive SE is the same as the full-cohort SE,",
        "even though there are far fewer observations (far fewer exposed!!) in the case-cohort; report the robust one)")

## =====================================================================
## PART B — BINARY-OUTCOME ANALYSES (the simple one-weight-per-person case)
## ---------------------------------------------------------------------
## The log-Poisson (risk ratio) and linear (risk difference) models are
## fit to ONE binary outcome per PERSON. Person-time never enters these
## models explicitly, so there is nothing to split: each person carries
## a single weight — the weight of their FINAL person-time segment from
## the split above. Type 1 -> 1/q (their whole follow-up is one segment
## at 1/q); Types 2 and 3 -> 1 (their final segment is the event, at
## weight 1). Same weighting logic as Part A, collapsed to one number
## per person because these models have no time axis.
## =====================================================================

## ---- B1: one weight per person, derived from the split  [TODO 5a completed]
w_exit <- cc |>
  group_by(id) |>
  slice_max(stop, n = 1, with_ties = FALSE) |>   # select each person's final segment
  ungroup() |>
  select(patientunitstayid = id, w)

head(w_exit)

head(samp)

samp <- samp |> left_join(w_exit, by = "patientunitstayid")

names(samp)
nrow(samp)
samp |> select(patientunitstayid, followup_days, death_event, w, subc)

# the weighted 2x2, next to the cohort's
print(samp |>
        count(early_vasopressor, hospital_death, wt = w, name = "weighted_n") |>
        mutate(cohort_n = c(b0, a0, b1, a1)))
message("sum(w) = ", sum(samp$w), "   (expect 1291)")

## ---- B2: weighted log-Poisson (RR) and linear (RD), case-cohort -----
fit_rr_cc <- glm(hospital_death ~ early_vasopressor,
                 family = poisson(link = "log"),
                 weights = w, data = samp)
message("weighted Poisson, naive (model-based):")
print(summary(fit_rr_cc)$coefficients)
message("weighted Poisson, robust (HC3):")
print(coeftest(fit_rr_cc, vcov = vcovHC(fit_rr_cc, type = "HC3")))
print(exp(coef(fit_rr_cc)["early_vasopressor"]))

fit_rd_cc <- lm(hospital_death ~ early_vasopressor,
                weights = w, data = samp)
message("weighted linear (RD), robust (HC3, robust only):")
print(coeftest(fit_rd_cc, vcov = vcovHC(fit_rd_cc, type = "HC3")))

## ---- B3: the same models in the original cohort ---------------------
fit_rr_full <- glm(hospital_death ~ early_vasopressor,
                   family = poisson(link = "log"), data = coh)
message("full-cohort Poisson, robust (HC3):")
print(coeftest(fit_rr_full, vcov = vcovHC(fit_rr_full, type = "HC3")))
print(exp(coef(fit_rr_full)["early_vasopressor"]))

fit_rd_full <- lm(hospital_death ~ early_vasopressor, data = coh)
message("full-cohort linear (RD), robust (HC3):")
print(coeftest(fit_rd_full, vcov = vcovHC(fit_rd_full, type = "HC3")))

## ---- B4: B2 and B3 side by side --------------------------------------
## One row per analysis; naive = model-based SE, robust = HC3 sandwich.
## Note the naive column of the risk-ratio table: the weighted
## case-cohort fit reproduces the full cohort's model-based SE.
glm_row <- function(fit, exponentiate = FALSE) {
  b  <- unname(coef(fit)["early_vasopressor"])
  nv <- unname(summary(fit)$coefficients["early_vasopressor", "Std. Error"])
  rb <- unname(sqrt(vcovHC(fit, type = "HC3")["early_vasopressor",
                                              "early_vasopressor"]))
  est <- c(b, b - 1.96 * rb, b + 1.96 * rb)
  if (exponentiate) est <- exp(est)
  c(estimate = est[1], naive_se = nv, robust_se = rb,
    lcl = est[2], ucl = est[3])
}

message("risk ratio (log-Poisson; estimate and CI on the RR scale):")
print(round(rbind(full_cohort = glm_row(fit_rr_full, exponentiate = TRUE),
                  case_cohort = glm_row(fit_rr_cc,   exponentiate = TRUE)), 3))

message("risk difference (linear risk model; robust CI):")
print(round(rbind(full_cohort = glm_row(fit_rd_full),
                  case_cohort = glm_row(fit_rd_cc))[, -2], 3))  # drop naive col (robust-only for the RD)

## =====================================================================
## PART C — ILLUSTRATIVE EXAMPLE:
## what happens to the KM and Cox results if we KEEP the person-time of
## cases not selected into the subcohort (the double-counting problem)
## ---------------------------------------------------------------------
## One change only: every case's row now runs from 0 to their event at
## weight 1, instead of covering only the event. The subcohort's 1/q
## comparison rows already represent ALL cohort person-time — including
## the pre-event follow-up of people who become cases — so this adds the
## cases' follow-up a second time.
## =====================================================================

cc_bad <- rbind(
  cc[cc$event == 0, ],   # subcohort comparison rows, unchanged
  with(subset(samp, hospital_death == 1),
       data.frame(id = patientunitstayid, a = early_vasopressor,
                  start = 0,                     # <- the only change
                  stop = followup_days, event = 1, w = 1))
)

# the design check catches it: person-time inflated, events unchanged
print(c(weighted_pt_bad = sum(cc_bad$w * (cc_bad$stop - cc_bad$start)),
        weighted_events_bad = sum(cc_bad$w[cc_bad$event == 1])))
message("case person-time = ",
        round(sum(coh$followup_days[coh$hospital_death == 1]), 1))

# effect on the KM: risks depressed at every horizon
km_bad <- survfit(Surv(start, stop, event) ~ 1, data = cc_bad, weights = w)
message("KM cumulative risks at 5 / 10 / 30 days, three ways:")
print(round(rbind(full_cohort    = risk_at(km_full, c(5, 10, 30)),
                  case_cohort    = risk_at(km_cc, c(5, 10, 30)),
                  double_counted = risk_at(km_bad, c(5, 10, 30))), 3))

# effect on the overall death rate (per 100 person-days)
print(round(100 * c(
  full_cohort = (a1 + a0) / sum(coh$followup_days),
  case_cohort = sum(cc$w[cc$event == 1]) / sum(cc$w * (cc$stop - cc$start)),
  double_counted = sum(cc_bad$w[cc_bad$event == 1]) /
    sum(cc_bad$w * (cc_bad$stop - cc_bad$start))
), 3))

# effect on the Cox model
cox_bad <- coxph(Surv(start, stop, event) ~ a,
                 data = cc_bad, weights = w, cluster = id)
message("Cox, three ways:")
print(round(rbind(
  full_cohort    = c(loghr = coef(cox_full), se = sqrt(vcov(cox_full)[1, 1])),
  case_cohort    = c(coef(cox_cc_robust), sqrt(cox_cc_robust$var[1, 1])),
  double_counted = c(coef(cox_bad), sqrt(cox_bad$var[1, 1]))), 3))
message("(the absolute quantities — risks, rates, the curve — are ",
        "systematically too low; BUT the Cox hazard ratio barely moves ",
        "because both arms' person-time inflates by roughly similar fractions.",
        "however, this is by chance and not reflective of the fact that it's ok to double count)")

## ---- replication  [provided; 2,000 subcohort draws] -----------------
## Closed-form weighted cells (these are exactly Part B's exit weights)
## and person-time, correct and double-counted, pooled across draws.
set.seed(42)
R    <- 2000
fu   <- coh$followup_days
expo <- coh$early_vasopressor
dth  <- coh$hospital_death
case_pt <- sum(fu[dth == 1])

one_rep <- function() {
  subc <- rbinom(length(fu), 1, q) == 1
  k1 <- sum(subc & expo == 1 & dth == 0)
  k0 <- sum(subc & expo == 0 & dth == 0)
  pt_sub <- (sum(fu[subc & dth == 0]) +
               sum(pmax(fu[subc & dth == 1] - eps, 0))) / q
  slivers <- sum(fu[dth == 1] - pmax(fu[dth == 1] - eps, 0))
  c(k1 = k1, k0 = k0,
    rr = (a1 / (a1 + k1 / q)) / (a0 / (a0 + k0 / q)),
    rd = a1 / (a1 + k1 / q) - a0 / (a0 + k0 / q),
    pt_w   = pt_sub + slivers,
    pt_bad = pt_sub + case_pt)
}

reps <- as_tibble(t(replicate(R, one_rep())))

## Pool the weighted cells / person-time across draws and set each
## quantity next to its full-cohort value. The iqr columns show the
## middle half of the SINGLE-draw estimates: wide for the ratio (noise),
## while the double-counted rate is narrow but off target (bias).
pooled_rr   <- (a1 / (a1 + mean(reps$k1) / q)) / (a0 / (a0 + mean(reps$k0) / q))
pooled_rd   <- a1 / (a1 + mean(reps$k1) / q) - a0 / (a0 + mean(reps$k0) / q)
cohort_rate <- 100 * (a1 + a0) / (pt1 + pt0)
rate_w      <- 100 * 136 / reps$pt_w     # each draw's correctly weighted rate
rate_bad    <- 100 * 136 / reps$pt_bad   # each draw's double-counted rate

iqr <- function(x) c(iqr_lo = unname(quantile(x, .25)),
                     iqr_hi = unname(quantile(x, .75)))

message("pooled over ", R, " subcohort draws, vs. the full cohort:")
print(round(rbind(
  risk_ratio          = c(full_cohort = rr_cohort,  pooled_draws = pooled_rr,
                          iqr(reps$rr)),
  risk_difference     = c(rd_cohort,   pooled_rd,   iqr(reps$rd)),
  rate_per100pd       = c(cohort_rate, 100 * 136 / mean(reps$pt_w),   iqr(rate_w)),
  rate_double_counted = c(cohort_rate, 100 * 136 / mean(reps$pt_bad), iqr(rate_bad))
), 3))
message("(first three rows: the design recovers the full-cohort answers ",
        "in expectation; last row: the double-counted rate misses its ",
        "target in every draw — bias, not noise)")

## ---- save-sample ----------------------------------------------------
dir.create("data", showWarnings = FALSE)
write_csv(samp, "data/case_cohort_sample.csv")
message("saved data/case_cohort_sample.csv: ", nrow(samp), " rows, ",
        ncol(samp), " columns   (expect 367 x 15)")

message("done.")
