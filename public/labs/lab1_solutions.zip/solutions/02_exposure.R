# ==================================================================
# INSTRUCTOR SOLUTION — all TODOs completed.
# 02_exposure.R — TARGET 6b–6c: treatment strategies and classification
#
# The two strategies compared:
#   (1) EARLY INITIATION — begin a vasopressor infusion
#       (norepinephrine, epinephrine, phenylephrine, vasopressin, or
#       dopamine) within 60 minutes of time zero;
#   (2) NO EARLY INITIATION — do not begin one within 60 minutes
#       (later initiation, per usual care, is allowed).
# In the target trial patients would be RANDOMIZED between these at
# time zero. Here we can only CLASSIFY them from the infusion
# records — the whole gap between item 6c as specified and as
# emulated.
#
# Also applies the remaining 6a criterion: no vasopressor infusion
# at any time BEFORE time zero (new users only — prevalent users
# cannot "initiate").
#
# Reads : data/derived/01_eligible.csv
#         data/raw/infusiondrug.csv.gz
# Writes: data/derived/02_exposure.csv
#
# Complete  >>> TODO (2a) ... (2c).  Checkpoint: 1,308 rows written.
# ==================================================================

pacman::p_load(tidyverse, data.table)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

eligible <- read_csv("data/derived/01_eligible.csv", show_col_types = FALSE)

# ---- Step 1: find the vasopressor infusions ----------------------
# infusiondrug has one row per charted infusion rate. `drugname` is
# free text: this demo alone spells the five agents 31 different
# ways — units, concentrations, brand names, odd casing, e.g.
#   "Norepinephrine (mcg/min)"
#   "Norepinephrine MAX 32 mg Dextrose 5% 250 ml (mcg/min)"
#   "EPINEPHrine(Adrenalin)STD 4 mg Sodium Chloride 0.9% 250 ml (mcg/min)"
#   "Neo-Synephrine (mcg/min)"

infusions <- fread("data/raw/infusiondrug.csv.gz",
                   select = c("patientunitstayid", "infusionoffset",
                              "drugname")) |>
  as_tibble()

## >>> TODO (2a) ----------------------------------------------------
## Build ONE case-insensitive regular expression that captures all
## five agents under every spelling, using generic AND brand names:
##   norepinephrine (brand: Levophed)
##   epinephrine    (brand: Adrenalin)
##   phenylephrine  (brand: Neo-Synephrine — note the hyphen may or
##                   may not be there; `.?` matches an optional
##                   single character)
##   vasopressin    (brand: Pitressin)
##   dopamine
## Alternatives are separated by `|`. Two agents below are started
## for you. (Worried that "epinephrine" also sits inside
## "NORepinephrine"? Think about whether that causes a wrong match
## here.)

vaso_pattern <- "norepinephrine|levophed|epinephrine|adrenalin|phenylephrine|neo.?synephrine|vasopressin|pitressin|dopamine"

## <<< --------------------------------------------------------------

# A small test battery — run it until everything passes. The last
# two are drugs that must NOT match: DOBUTamine is an inotrope, not
# one of our five agents, and nicardipine LOWERS blood pressure.
should_match <- c("Norepinephrine (mcg/min)",
                  "EPINEPHrine(Adrenalin)STD 4 mg Sodium Chloride 0.9% 250 ml (mcg/min)",
                  "Neo-Synephrine (mcg/min)", "neosynephrine",
                  "Vasopressin (units/min)", "DOPamine STD 400 mg (mcg/kg/min)")
should_not  <- c("Dobutamine (mcg/kg/min)", "Nicardipine (mg/hr)")

stopifnot(
  "pattern misses a vasopressor spelling" =
    all(str_detect(should_match, regex(vaso_pattern, ignore_case = TRUE))),
  "pattern wrongly matches a non-vasopressor" =
    !any(str_detect(should_not, regex(vaso_pattern, ignore_case = TRUE)))
)
message("drugname pattern: all tests pass")

vaso_infusions <- infusions |>
  filter(str_detect(drugname, regex(vaso_pattern, ignore_case = TRUE))) |>
  select(patientunitstayid, infusionoffset)

message("Vasopressor infusion rows: ", nrow(vaso_infusions),
        " in ", n_distinct(vaso_infusions$patientunitstayid),
        " stays  (expect 7,454 rows in 245 stays)")

# ---- Step 2: new users only (a 6a criterion, applied here) -------
# Timing of each stay's vasopressor infusions relative to ITS time
# zero. (Provided: a per-stay summary of the earliest infusion
# before time zero and the earliest at/after it.)

vaso_timing <- eligible |>
  select(patientunitstayid, time_zero_offset) |>
  inner_join(vaso_infusions, by = "patientunitstayid",
             relationship = "one-to-many") |>
  group_by(patientunitstayid) |>
  summarise(
    first_vaso_before_t0 = suppressWarnings(
      min(infusionoffset[infusionoffset <  time_zero_offset])),
    first_vaso_after_t0  = suppressWarnings(
      min(infusionoffset[infusionoffset >= time_zero_offset])),
    .groups = "drop"
  ) |>
  mutate(across(starts_with("first_vaso"),
                \(x) if_else(is.infinite(x), NA_real_, x)))

## >>> TODO (2b) ----------------------------------------------------
## Exclude prevalent users: any stay whose infusion record shows a
## qualifying vasopressor STRICTLY BEFORE its time zero. These
## patients were already being treated when they became "eligible" —
## in the target trial they could not be enrolled, because neither
## strategy ("initiate within 60 min" / "do not initiate within
## 60 min") describes someone already on the drug.
## Replace the ??? with the condition that KEEPS new users.

exposure_base <- eligible |>
  left_join(vaso_timing, by = "patientunitstayid") |>
  filter(is.na(first_vaso_before_t0))

## <<< --------------------------------------------------------------

message("After new-user criterion: ", nrow(exposure_base),
        "  (expect 1,308 — i.e., 70 prevalent users excluded)")

# ---- Step 3: classify the strategies -----------------------------

## >>> TODO (2c) ----------------------------------------------------
## Create the two exposure variables:
##   first_vasopressor_offset — the first qualifying infusion at or
##       after time zero (already computed above under another name;
##       NA if the stay never has one);
##   early_vasopressor — 1 if initiation occurred within the
##       60-minute grace period [t0, t0 + 60], else 0. A patient who
##       initiates at minute 61 or later is 0: that is not a coding
##       convenience, it is what strategy (2), "no EARLY
##       initiation", MEANS.
## Replace the ???s.

exposure <- exposure_base |>
  mutate(
    first_vasopressor_offset = first_vaso_after_t0,
    early_vasopressor = if_else(
      !is.na(first_vasopressor_offset) &
        first_vasopressor_offset <= time_zero_offset + 60,
      1L, 0L)
  ) |>
  select(-first_vaso_before_t0, -first_vaso_after_t0)

## <<< --------------------------------------------------------------

# ---- Step 4: save ------------------------------------------------

write_csv(exposure, "data/derived/02_exposure.csv")

message("Written data/derived/02_exposure.csv: ", nrow(exposure),
        " rows  (expect 1,308)")
