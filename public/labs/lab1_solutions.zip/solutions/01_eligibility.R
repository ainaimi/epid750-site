# ==================================================================
# INSTRUCTOR SOLUTION — all TODOs completed.
# 01_eligibility.R — TARGET 6a: eligibility criteria and time zero
#
# Who would be enrolled in the target trial, and at what moment?
# Here: adult (>=18) first-ICU-stay patients, enrolled at the moment
# of their first hypotensive measurement (MAP < 65 mmHg) during the
# ICU stay. (One further 6a criterion — no vasopressor use before
# time zero — is applied in 02_exposure.R, because it needs the
# cleaned infusion data.)
#
# Reads : data/raw/patient.csv.gz
#         data/raw/vitalPeriodic.csv.gz    (invasive MAP, heart rate)
#         data/raw/vitalAperiodic.csv.gz   (cuff MAP)
# Writes: data/derived/01_eligible.csv     (one row per eligible stay)
#
# Complete the sections marked  >>> TODO (1a) ... (1c).
# The ??? placeholders are not valid R — the script stops until you
# replace them. Checkpoint: the final message should report 1,378
# eligible stays.
# ==================================================================

pacman::p_load(tidyverse, data.table)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

# ---- Step 1: ICU stays (patient table) ---------------------------
# The patient table has one row per ICU stay. Ages over 89 are
# masked as the string "> 89" (a de-identification rule); we recode
# them to 90. Everything else parses as a number; the 4 stays with
# no recorded age become NA.

patient <- fread("data/raw/patient.csv.gz") |>
  as_tibble() |>
  mutate(
    age_num = if_else(age == "> 89", 90, suppressWarnings(as.numeric(age))),
    sex     = na_if(gender, "")
  )

## >>> TODO (1a) ----------------------------------------------------
## Apply the two eligibility criteria we can assess from this table:
##   (i)  adults only: age 18 or older (this also drops missing age);
##   (ii) the FIRST ICU stay of the hospitalization, so each
##        hospitalization contributes at most one trial entry
##        (which variable in the patient table counts a patient's
##        ICU visits within a hospitalization?).
## Replace the ??? below.

stays <- patient |>
  filter(
    age_num >= 18,
    unitvisitnumber == 1
  ) |>
  select(patientunitstayid, age = age_num, sex,
         unitdischargeoffset, unitdischargestatus,
         hospitaldischargeoffset, hospitaldischargestatus)

## <<< --------------------------------------------------------------

message("Adult first-ICU stays: ", nrow(stays), "  (expect 2,111)")

# ---- Step 2: one MAP series from two measurement sources ---------
# Mean arterial pressure lives in TWO tables, because it is measured
# two ways: continuously from an arterial line (vitalPeriodic,
# `systemicmean`) and intermittently from a cuff (vitalAperiodic,
# `noninvasivemean`). Only ~430 of 2,520 stays have an arterial
# line — the sickest patients — so using invasive MAP alone would
# quietly restrict the trial to them. We stack both sources into one
# long series and record which source each value came from.

vp <- fread("data/raw/vitalPeriodic.csv.gz",
            select = c("patientunitstayid", "observationoffset",
                       "systemicmean", "heartrate")) |>
  as_tibble()

va <- fread("data/raw/vitalAperiodic.csv.gz",
            select = c("patientunitstayid", "observationoffset",
                       "noninvasivemean")) |>
  as_tibble()

map_long <- bind_rows(
  vp |>
    filter(!is.na(systemicmean)) |>
    transmute(patientunitstayid, observationoffset,
              map = systemicmean, map_source = "invasive"),
  va |>
    filter(!is.na(noninvasivemean)) |>
    transmute(patientunitstayid, observationoffset,
              map = noninvasivemean, map_source = "cuff")
)

## >>> TODO (1b) ----------------------------------------------------
## Not every recorded value is a real blood pressure: this series
## contains values like -45 and 353 mmHg (transducer flushes, cuff
## artifacts). Keep only:
##   (i)  plausible values: MAP between 30 and 150 mmHg (inclusive);
##   (ii) measurements taken during the ICU stay: offset at or after
##        ICU admission (offsets are minutes; admission is 0).
## Replace the ??? below.

map_valid <- map_long |>
  filter(
    map >= 30, map <= 150,
    observationoffset >= 0
  )

## <<< --------------------------------------------------------------

# ---- Step 3: index hypotensive event = time zero -----------------
# Enrollment happens at the FIRST measured MAP below 65 mmHg. That
# instant is this trial's time zero: eligibility is assessed there,
# strategies are defined relative to it, and (after the landmark —
# see 03) follow-up is anchored to it.

## >>> TODO (1c) ----------------------------------------------------
## From `map_valid`, keep the hypotensive measurements, then reduce
## to ONE row per stay: the earliest one. The arrange() is provided —
## it sorts each stay's rows by time (ties broken by source name,
## arbitrary but reproducible); your job is the filter and the
## one-row-per-stay step (hint: distinct() with .keep_all = TRUE
## keeps the first row it sees for each id).

index_events <- map_valid |>
  filter(map < 65) |>
  arrange(patientunitstayid, observationoffset, map_source) |>
  distinct(patientunitstayid, .keep_all = TRUE) |>
  transmute(patientunitstayid,
            time_zero_offset    = observationoffset,
            baseline_map        = map,
            baseline_map_source = map_source)

## <<< --------------------------------------------------------------

# ---- Step 4: baseline heart rate ---------------------------------
# (Provided.) The nearest heart-rate measurement within +/-60 min of
# time zero; NA for the few stays with none in that window. On exact
# ties (equidistant before/after), the earlier measurement wins.

hr <- vp |>
  filter(!is.na(heartrate)) |>
  select(patientunitstayid, observationoffset, heartrate)

baseline_hr_tbl <- index_events |>
  select(patientunitstayid, time_zero_offset) |>
  inner_join(hr, by = "patientunitstayid",
             relationship = "one-to-many") |>
  filter(abs(observationoffset - time_zero_offset) <= 60) |>
  arrange(patientunitstayid, abs(observationoffset - time_zero_offset)) |>
  distinct(patientunitstayid, .keep_all = TRUE) |>
  select(patientunitstayid, baseline_hr = heartrate)

# ---- Step 5: assemble and save -----------------------------------
# (Provided.) One row per eligible stay: the stay-level criteria
# (Step 1) AND an index event (Step 3), plus baseline heart rate.

eligible <- stays |>
  inner_join(index_events, by = "patientunitstayid") |>
  left_join(baseline_hr_tbl, by = "patientunitstayid")

write_csv(eligible, "data/derived/01_eligible.csv")

message("Eligible stays written to data/derived/01_eligible.csv: ",
        nrow(eligible), "  (expect 1,378)")
