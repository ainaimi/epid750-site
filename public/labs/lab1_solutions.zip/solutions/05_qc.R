# ==================================================================
# INSTRUCTOR SOLUTION — all TODOs completed.
# 05_qc.R — quality control on the analytic dataset
#
# No estimation here: QC verifies that the dataset SAYS what the
# protocol MEANS. Two kinds of checks:
#   - INVARIANTS: must hold by construction — a failure means a bug
#     in YOUR pipeline (checks 4, 5, 6, 7a);
#   - REPORTS: counts to look at and interpret — nonzero is not
#     necessarily wrong, but you must be able to explain it
#     (checks 1, 2, 3, 7b, 8).
#
# Reads : data/derived/analytic_dataset.csv
#         data/derived/01_… 02_… 03_… (flow counts, source offsets)
# Writes: nothing — prints a QC report to the console
#
# Complete  >>> TODO (5a) and (5b).
# ==================================================================

pacman::p_load(tidyverse)

if (!file.exists("lab.qmd")) {
  stop("Working directory must be the lab1 folder (open lab1.Rproj first).")
}

analytic <- read_csv("data/derived/analytic_dataset.csv", show_col_types = FALSE)
eligible <- read_csv("data/derived/01_eligible.csv",      show_col_types = FALSE)
exposure <- read_csv("data/derived/02_exposure.csv",      show_col_types = FALSE)
outcomes <- read_csv("data/derived/03_outcome.csv",       show_col_types = FALSE)

invariant <- function(label, n_violations) {
  cat(sprintf("  [%s] %-55s violations: %d\n",
              if (n_violations == 0) "PASS" else "FAIL",
              label, n_violations))
}

cat("==================== QC REPORT ====================\n")

# ---- Check 1 (report): participant flow --------------------------
cat("\n1. Participant flow (a real report would draw this — TARGET item 8):\n")
cat(sprintf("   %-52s %5d\n", "eligible w/ index hypotension (01)", nrow(eligible)))
cat(sprintf("   %-52s %5d\n", "+ no vasopressor before time zero (02)", nrow(exposure)))
cat(sprintf("   %-52s %5d\n", "+ alive & in ICU at 60-min landmark (03)", nrow(outcomes)))
cat(sprintf("   %-52s %5d\n", "analytic dataset (04)", nrow(analytic)))

# ---- Check 2 (report): group sizes -------------------------------
cat("\n2. Strategy classification:\n")
analytic |>
  count(early_vasopressor) |>
  mutate(pct = round(100 * n / sum(n), 1)) |>
  print()

# ---- Check 3 (report): deaths and outcome missingness ------------
cat("\n3. Outcome:\n")
cat(sprintf("   in-hospital deaths: %d of %d with a recorded status; missing status: %d\n",
            sum(analytic$hospital_death, na.rm = TRUE),
            sum(!is.na(analytic$hospital_death)),
            sum(is.na(analytic$hospital_death))))

# ---- Check 4 (invariant): one row per stay -----------------------
cat("\n4. Uniqueness:\n")
invariant("duplicated patientunitstayid",
          sum(duplicated(analytic$patientunitstayid)))

# ---- Check 5 (invariant): binary coding --------------------------
cat("\n5. Binary coding:\n")
invariant("early_vasopressor not in {0, 1}",
          sum(!analytic$early_vasopressor %in% c(0, 1)))
invariant("hospital_death not in {0, 1, NA}",
          sum(!analytic$hospital_death %in% c(0, 1) &
                !is.na(analytic$hospital_death)))

# ---- Check 6 (invariant): treatment timing -----------------------
# By construction, no one initiates before time zero (they were
# excluded as prevalent users), and everyone classified as an early
# initiator started within the grace period. If either count is
# nonzero, the bug is in 02 or 03 — not in the data.
cat("\n6. Treatment timing:\n")

## >>> TODO (5a) ----------------------------------------------------
## Fill in the two violation conditions (each inside sum(..., na.rm
## = TRUE) so NAs — never-initiators — do not count):
##   (i)  initiation recorded BEFORE time zero;
##   (ii) early_vasopressor == 1 but initiation AFTER the landmark.

invariant("first_vasopressor_offset before time zero",
          sum(analytic$first_vasopressor_offset < analytic$time_zero_offset, na.rm = TRUE))
invariant("early initiator with initiation after landmark",
          sum(analytic$early_vasopressor == 1 & analytic$first_vasopressor_offset > analytic$landmark_offset, na.rm = TRUE))

## <<< --------------------------------------------------------------

# ---- Check 7: follow-up ------------------------------------------
cat("\n7. Follow-up:\n")

## >>> TODO (5b) ----------------------------------------------------
## 7a (invariant): follow-up must be strictly positive — a
## nonpositive value means discharge at or before the landmark,
## which the landmark filter should have made impossible. Fill in
## the condition.

invariant("followup_days <= 0", sum(analytic$followup_days <= 0))

## <<< --------------------------------------------------------------

# 7b (report; provided): source-data inconsistencies. A few stays
# have hospital discharge recorded BEFORE ICU discharge — impossible
# on its face, and a reminder that EHR timestamps are entered by
# humans. These survive to the analytic dataset (their follow-up is
# computed from the hospital offset); count them and note them as a
# limitation.
cat(sprintf("   [note] hospital discharge before ICU discharge (source records): %d\n",
            sum(outcomes$hospitaldischargeoffset < outcomes$unitdischargeoffset)))
cat("   followup_days summary (days):\n")
print(summary(analytic$followup_days))

# ---- Check 8 (report): missingness -------------------------------
cat("\n8. Missingness in the analytic dataset:\n")
analytic |>
  summarise(across(c(age, sex, baseline_map, baseline_hr, hospital_death),
                   \(x) sum(is.na(x)))) |>
  pivot_longer(everything(), names_to = "variable", values_to = "n_missing") |>
  print()

cat("\n==================== END QC =======================\n")
