# Lab 6 — Compute Variance Three Ways

A lab about the *standard error*, and the first lab in which no data
are loaded: every dataset is drawn by a short data-generating function
in which the truth is known (the exposure coefficient is 2), so that
each standard error can be checked against the one thing it is supposed
to estimate, the standard deviation of the estimates across repeated
samples. One linear model, `y ~ x + z`, all morning; two dials,
turned one at a time.

- **One sample, by hand** (Step 1): the model-based sandwich
  (`s2 = 1.716` on every diagonal) and the HC0 / HC3 sandwiches (each
  person's own squared residual, from 0 to 25.2) from the design matrix
  and the residuals, matching `vcov()` and `vcovHC()` to machine
  precision; exposure SE 0.193 model-based vs 0.261 (HC0) / 0.262 (HC1)
  / 0.263 (HC2) / 0.265 (HC3); then a table that reproduces, by
  formula, what R, Stata, and SAS each print by default for this model
  (0.265 / 0.262 / 0.261), with the Stata and SAS code behind it, and
  the sample written to `lab6_sample.csv` for anyone who wants to check.
- **Two thousand samples** (Step 2): in a homoscedastic world all
  three SEs average to the Monte Carlo SD (0.15) and cover 95%; when
  the rarer exposed group is twice as variable, the model-based SE
  averages 0.190 against a true 0.272 and covers 83% while HC3 covers
  95%; flip which group is more variable and the model-based SE is a
  third too *large* (coverage 99%); at n = 80, HC0 covers 92% and HC3
  94%.
- **The bootstrap** (Step 3): by hand (SD of 1,000 replicates, 0.275,
  the robust answer, with no instruction about heteroscedasticity) and
  with `boot()` + `boot.ci()`; and a 500 × 200 nested simulation
  (bootstrap normal interval covers 95%, percentile 93%).
- **Bonus**: Lab 5's Q3 by simulation. A Poisson model for a binary
  outcome has a model-based SE 60% too large at a risk of 0.56 and 5%
  too large at 0.11; the robust SE is right at both.

## Quick start

1. Open `lab6.Rproj` in RStudio.
2. No data to download. The lab simulates everything it uses.
3. Packages: `pacman::p_load(tidyverse, sandwich, lmtest, boot)`
   (`boot` ships with R; `sandwich` and `lmtest` were Labs 2 and 5).
4. Open `lab.qmd` and work top to bottom. Four chunks contain `TODO`s
   (with `???` placeholders that error until fixed); everything else is
   provided, and much of the work is in the questions.
5. When the `TODO` chunks run, flip `eval: false` to `eval: true` in
   the YAML header and render to HTML. The whole document runs in
   under a minute (about 20 seconds on a recent laptop). Every chunk
   that draws random numbers sets its own seed, so the numbers in the
   checkpoints reproduce exactly.

Deliverables are **yours to keep** — the rendered HTML is not
submitted; keep it for exam preparation.

## Folder layout

```
lab.qmd                   the lab document — start here
lab6.Rproj                RStudio project anchor
lab6_sample.csv           written by Step 1 (the one sample), for Stata or SAS
```

## Readings the lab leans on

- The Week 7 lecture notes, *Variance Estimation*.
- Mansournia et al., *Int J Epidemiol* 2021 (reading list): the
  by-hand sandwich of Step 1.
- Long & Ervin, *Am Stat* 2000: why HC3 in small samples (Step 2).
- Efron & Tibshirani, *An Introduction to the Bootstrap*, 1993 (Step 3).
