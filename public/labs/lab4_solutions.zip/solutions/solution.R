# Lab 4 — Dissect a Regression Model: solution script
# The lab.qmd chunk code in chunk order, with the four TODOs (1a, 1b, 2a, 2b)
# completed; the Step 3 chunk is provided in the handout (instructor's
# 2026-10-04 edit, which also moved several prose passages).
# Run from the lab root (labs/lab4/): Rscript solutions/solution.R
# Prints every checkpoint in the handout (plus a few extras the answer key
# quotes), and writes no files. No seeds: the lab is fully deterministic
# given the canonical Lab 1 dataset.

## ---- setup ------------------------------------------------------------
pacman::p_load(tidyverse, splines)

paths <- c("../lab1/data/derived/analytic_dataset.csv",  # Lab 1, completed in place
           "data/analytic_dataset.csv")                  # or the website copy
path <- paths[file.exists(paths)][1]
if (is.na(path)) {
  stop("analytic_dataset.csv not found. Complete Lab 1 first, or download ",
       "the dataset from the website into labs/lab4/data/.")
}
lab1 <- read_csv(path, show_col_types = FALSE)
cat("setup: nrow(lab1) =", nrow(lab1), "  # expect 1,292\n")
coh <- lab1 |> filter(!is.na(hospital_death))
cat("setup: nrow(coh)  =", nrow(coh), "  # expect 1,274\n\n")

## ---- parts-list (Step 0) ------------------------------------------------
cat("Step 0 — the parts list:\n")
fit_lab3 <- glm(hospital_death ~ early_vasopressor + age + sex +
                  baseline_map + baseline_hr,
                family = binomial, data = coh)
print(formula(fit_lab3))
cat("family:", fit_lab3$family$family, " link:", fit_lab3$family$link,
    " offset NULL:", is.null(fit_lab3$offset),
    " parameters:", length(coef(fit_lab3)), "\n\n")

## ---- three-links-exposure (Step 1a) ------------------------------------
cat("Step 1a — three links, exposure only (saturated):\n")
fit_id  <- glm(hospital_death ~ early_vasopressor,
               family = binomial(link = "identity"), data = coh)
# TODO (1a) completed. (Instructor's 2026-10-04 edit: the link names are
# now given in the handout; the blanks are coef(fit_id/log/lgt),
# exp(coef(fit_log)), exp(coef(fit_lgt)), and fitted(fit_id/log/lgt).)
fit_log <- glm(hospital_death ~ early_vasopressor,
               family = binomial(link = "log"), data = coh)
fit_lgt <- glm(hospital_death ~ early_vasopressor,
               family = binomial(link = "logit"), data = coh)
print(round(rbind(identity = coef(fit_id), log = coef(fit_log),
                  logit = coef(fit_lgt)), 4))
cat("# expect exposure coef 0.1180 / 0.7569 / 0.8981\n")
cat("exp(log):   ", round(exp(coef(fit_log)), 3), "  # expect 0.104, 2.132 (RR)\n")
cat("exp(logit): ", round(exp(coef(fit_lgt)), 3), "  # expect 0.116, 2.455 (OR)\n")
print(rbind(identity = sort(unique(round(fitted(fit_id),  4))),
            log      = sort(unique(round(fitted(fit_log), 4))),
            logit    = sort(unique(round(fitted(fit_lgt), 4)))))
cat("# expect 0.1042 / 0.2222 in every row\n")
print(round(c(identity = deviance(fit_id), log = deviance(fit_log),
              logit = deviance(fit_lgt)), 2))
cat("# expect 862.40 x3\n")
print(round(c(identity = sum(coef(fit_id)), log = exp(sum(coef(fit_log))),
              logit = plogis(sum(coef(fit_lgt)))), 4))
cat("# inverse links by hand: all 0.2222\n")
cat("SE of the exposure coef by link:",
    round(c(sqrt(vcov(fit_id)[2, 2]), sqrt(vcov(fit_log)[2, 2]),
            sqrt(vcov(fit_lgt)[2, 2])), 3), "  # expect 0.080 / 0.369 / 0.472\n")
# aside box (provided): logistic model's vcov -> log RR SE -> RD SE by the delta method
beta <- coef(fit_lgt); V <- vcov(fit_lgt)
p0 <- plogis(beta[[1]]); p1 <- plogis(beta[[1]] + beta[[2]])
g_logRR <- c(p0 - p1, 1 - p1)
g_RD    <- c(p1 * (1 - p1) - p0 * (1 - p0), p1 * (1 - p1))
print(round(c(logRR_se_delta = sqrt(drop(t(g_logRR) %*% V %*% g_logRR)),
              logRR_se_glm   = sqrt(vcov(fit_log)[2, 2]),
              RD_se_delta    = sqrt(drop(t(g_RD) %*% V %*% g_RD)),
              RD_se_glm      = sqrt(vcov(fit_id)[2, 2])), 4))
cat("# expect 0.3695 / 0.3695 / 0.0805 / 0.0805\n")
# key-only extra: the hand formulas (not in the handout since the 2026-10-04 simplification)
cells <- c(a = 6, b = 21, c = 130, d = 1117)
cat("hand formulas: RD", round(sqrt(p1 * (1 - p1) / 27 + p0 * (1 - p0) / 1247), 4),
    " logRR", round(sqrt((1 - p1) / cells[["a"]] + (1 - p0) / cells[["c"]]), 4),
    " logOR (Woolf)", round(sqrt(sum(1 / cells)), 4),
    " vs glm logOR SE", round(sqrt(vcov(fit_lgt)[2, 2]), 6), "\n\n")

## ---- three-links-age (Step 1b) -----------------------------------------
cat("Step 1b — three links, age (unsaturated):\n")
# TODO (1b) completed: "~ age"
fit_log_age <- glm(hospital_death ~ age, family = binomial(link = "log"),   data = coh)
fit_lgt_age <- glm(hospital_death ~ age, family = binomial(link = "logit"), data = coh)
print(round(rbind(log = coef(fit_log_age), logit = coef(fit_lgt_age)), 4))
cat("# expect age coef 0.0363 (log) / 0.0409 (logit)\n")
print(round(c(RR_per_year = exp(coef(fit_log_age)[["age"]]),
              OR_per_year = exp(coef(fit_lgt_age)[["age"]])), 3))
cat("# expect 1.037 / 1.042; per decade",
    round(exp(10 * coef(fit_log_age)["age"]), 3),
    round(exp(10 * coef(fit_lgt_age)["age"]), 3), "\n")
cat("IRLS iterations, log / logit:", fit_log_age$iter, fit_lgt_age$iter, "\n")
fit_id_age <- tryCatch(
  glm(hospital_death ~ age, family = binomial(link = "identity"), data = coh),
  error = function(e) conditionMessage(e))
cat("identity link returns:", fit_id_age, "\n")
fit_lpm_age <- lm(hospital_death ~ age, data = coh)
cat("least-squares line:", round(coef(fit_lpm_age), 4),
    "  # expect -0.0894, 0.0030\n")
cat("patients with negative LPM fitted risk:", sum(fitted(fit_lpm_age) < 0),
    "  # expect 73\n")
ages <- data.frame(age = c(18, 40, 65, 80, 90))
print(round(cbind(ages,
                  log      = predict(fit_log_age, ages, type = "response"),
                  logit    = predict(fit_lgt_age, ages, type = "response"),
                  identity = predict(fit_lpm_age, ages)), 3))
cat("# expect log 0.016/0.036/0.090/0.155/0.223; logit 0.014/0.035/0.091/0.156/0.218;",
    "identity -0.035/0.032/0.107/0.153/0.183\n")
cat("AIC log / logit:", round(AIC(fit_log_age), 2), round(AIC(fit_lgt_age), 2), "\n")
cat("deaths among ages 18-27:", sum(coh$hospital_death[coh$age <= 27]),
    " of", sum(coh$age <= 27), "patients\n")
# instructor aside (not in the handout): with hand-picked starting values and
# many iterations the identity-link MLE sits on the boundary, risk = 0 at age 18
id_boundary <- suppressWarnings(tryCatch(
  glm(hospital_death ~ age, family = binomial(link = "identity"), data = coh,
      start = c(0.001, 0.0017), control = glm.control(maxit = 500)),
  error = function(e) NULL))
if (!is.null(id_boundary))
  cat("identity with start=c(0.001,0.0017), maxit=500: converged =",
      id_boundary$converged, " coef", round(coef(id_boundary), 5),
      " fitted at 18 =", round(sum(coef(id_boundary) * c(1, 18)), 6), "\n")
cat("\n")

## ---- Step 2: offset ------------------------------------------------------
cat("Step 2 — the offset:\n")
fit_pois <- glm(hospital_death ~ early_vasopressor,
                family = poisson(link = "log"), data = coh)
cat("Poisson, no offset, exp(coef):", round(exp(coef(fit_pois)), 4),
    "  # expect 0.1043, 2.1316 (Lab 2's RR)\n")
# TODO (2a) completed: sum(hospital_death), sum(followup_days)
rates <- coh |>
  group_by(early_vasopressor) |>
  summarise(n      = n(),
            deaths = sum(hospital_death),
            pdays  = sum(followup_days),
            risk   = deaths / n,
            rate   = deaths / pdays)
print(as.data.frame(rates), digits = 7)
cat("# expect pdays 7310.06 / 168.35 (total", round(sum(coh$followup_days), 1), ")\n")
cat("rates per 100 person-days:", round(100 * rates$rate, 2), "  # expect 1.78 / 3.56\n")
print(c(RR = rates$risk[2] / rates$risk[1], IRR = rates$rate[2] / rates$rate[1]))
cat("# expect RR 2.1316, IRR 2.0041\n")
# TODO (2b) completed: offset(log(followup_days))
fit_rate <- glm(hospital_death ~ early_vasopressor + offset(log(followup_days)),
                family = poisson(link = "log"), data = coh)
cat("offset model coef:", round(coef(fit_rate), 4), "  # expect -4.0295, 0.6952\n")
cat("offset model exp(coef):", round(exp(coef(fit_rate)), 4),
    "  # expect 0.0178, 2.0041 (= hand IRR)\n")
cat("unexposed rate per 100 pd:", round(100 * exp(coef(fit_rate)[1]), 3), "\n")
cat("SE of exposure coef, no offset / offset:",
    round(sqrt(vcov(fit_pois)[2, 2]), 4), round(sqrt(vcov(fit_rate)[2, 2]), 4),
    "  # expect 0.4176 / 0.4175\n")
cat("95% CI for the IRR:",
    round(exp(coef(fit_rate)[2] + c(-1, 1) * 1.96 * sqrt(vcov(fit_rate)[2, 2])), 3), "\n")
fit_free <- glm(hospital_death ~ early_vasopressor + log(followup_days),
                family = poisson(link = "log"), data = coh)
cat("log(followup) unconstrained (estimated), coef:", round(coef(fit_free), 4),
    "  # expect -2.0139, 0.6387, -0.2348\n")
cat("exposure exp(coef) when free:", round(exp(coef(fit_free)[2]), 3), "  # expect 1.894\n")
cat("deviance offset / free:", round(deviance(fit_rate), 2), round(deviance(fit_free), 2),
    "  # expect 863.03 / 592.88\n")
print(coh |>
        group_by(early_vasopressor, hospital_death) |>
        summarise(n = n(), median_days = round(median(followup_days), 2),
                  mean_days = round(mean(followup_days), 2), .groups = "drop"))
cat("# expect medians 3.92 / 2.75 / 7.94 / 1.73\n")
mt <- coh |> group_by(early_vasopressor) |> summarise(m = mean(followup_days))
cat("mean follow-up unexposed / exposed:", round(mt$m, 3),
    " ratio:", round(mt$m[1] / mt$m[2], 4),
    "  # IRR = RR x this ratio =", round(2.131624 * mt$m[1] / mt$m[2], 4), "\n")
two_rows <- coh |>
  group_by(early_vasopressor) |>
  summarise(deaths = sum(hospital_death), pdays = sum(followup_days))
fit_rate_2 <- glm(deaths ~ early_vasopressor + offset(log(pdays)),
                  family = poisson(link = "log"), data = two_rows)
print(round(rbind(individual = coef(fit_rate), aggregated = coef(fit_rate_2)), 6))
cat("max |coef difference|:", signif(max(abs(coef(fit_rate) - coef(fit_rate_2))), 2), "\n")
cat("SE exposure, individual / aggregated:", sqrt(vcov(fit_rate)[2, 2]),
    sqrt(vcov(fit_rate_2)[2, 2]), "  # differ in the 5th decimal (see key notes)\n\n")

## ---- Step 3: three ways --------------------------------------------------
cat("Step 3 — one relationship in three ways:\n")
# Step 3 chunk: provided in the handout (no TODO); the three formulas are
# age / ns(age, df = 4) / factor(age)
fit_lin <- glm(hospital_death ~ age,             family = binomial, data = coh)
fit_spl <- glm(hospital_death ~ ns(age, df = 4), family = binomial, data = coh)
fit_sat <- glm(hospital_death ~ factor(age),     family = binomial, data = coh)
spectrum <- data.frame(
  model      = c("linear", "natural spline (df = 4)", "saturated"),
  parameters = c(length(coef(fit_lin)), length(coef(fit_spl)), length(coef(fit_sat))),
  deviance   = round(c(deviance(fit_lin), deviance(fit_spl), deviance(fit_sat)), 2),
  AIC        = round(c(AIC(fit_lin), AIC(fit_spl), AIC(fit_sat)), 2))
print(spectrum)
cat("# expect 2/5/73; deviance 820.60/815.95/760.23; AIC 824.60/825.95/906.23\n")
cat("null deviance:", round(fit_lin$null.deviance, 2), "  # expect 865.47\n")
cat("ns knots:", attr(ns(coh$age, df = 4), "knots"), " boundary:",
    attr(ns(coh$age, df = 4), "Boundary.knots"), "  # expect 55 68 78; 18 90\n")
cat("LRT spline vs linear: diff", round(deviance(fit_lin) - deviance(fit_spl), 2),
    "on 3 df, p =", round(pchisq(deviance(fit_lin) - deviance(fit_spl), 3, lower.tail = FALSE), 3), "\n")
cat("LRT saturated vs spline: diff", round(deviance(fit_spl) - deviance(fit_sat), 2),
    "on", length(coef(fit_sat)) - length(coef(fit_spl)), "df, p =",
    round(pchisq(deviance(fit_spl) - deviance(fit_sat),
                 length(coef(fit_sat)) - length(coef(fit_spl)), lower.tail = FALSE), 3), "\n")
cat("saturated fit: iterations", fit_sat$iter, " converged", fit_sat$converged, "\n")
by_age <- coh |>
  group_by(age) |>
  summarise(n = n(), deaths = sum(hospital_death), p_obs = mean(hospital_death))
by_age$p_sat <- predict(fit_sat, newdata = data.frame(age = by_age$age), type = "response")
cat("max |p_obs - saturated logit fit|:", signif(max(abs(by_age$p_obs - by_age$p_sat)), 2),
    "  # ~1e-8\n")
by_age$p_sat_lm <- predict(lm(hospital_death ~ factor(age), data = coh),
                           newdata = data.frame(age = by_age$age))
cat("max |p_obs - saturated lm fit|:", signif(max(abs(by_age$p_obs - by_age$p_sat_lm)), 2),
    "  # ~1e-14\n")
print(as.data.frame(by_age |> filter(age %in% c(18, 28, 44, 85, 88, 90))))
cat("# expect 0/7, 1/10, 0/3, 6/15, 1/13, 14/59\n")
cat("ages with zero deaths:", sum(by_age$deaths == 0), " (patients:", sum(by_age$n[by_age$deaths == 0]), ")",
    " n per age: min", min(by_age$n), " median", median(by_age$n), " max", max(by_age$n), "\n")
print(round(summary(fit_sat)$coefficients[c("(Intercept)", "factor(age)19", "factor(age)28"), ], 2))
cat("# expect intercept ~ -18.6 with SE in the thousands; age 28 ~ +16.4\n")
# extras for the key: a step-function model between spline and saturated
fit_dec <- glm(hospital_death ~ cut(age, c(18, 30, 40, 50, 60, 70, 80, 90),
                                    include.lowest = TRUE, right = FALSE),
               family = binomial, data = coh)
cat("decade bins (<30,30s,...,80+): parameters", length(coef(fit_dec)),
    " deviance", round(deviance(fit_dec), 2), " AIC", round(AIC(fit_dec), 2), "\n")
nd61 <- data.frame(age = 61)
cat("fitted risk at age 61: linear", round(predict(fit_lin, nd61, type = "response"), 3),
    " spline", round(predict(fit_spl, nd61, type = "response"), 3),
    " saturated", round(predict(fit_sat, nd61, type = "response"), 3),
    " (1 of", by_age$n[by_age$age == 61], "); at 60 saturated =",
    round(by_age$p_obs[by_age$age == 60], 3), "\n")
ci85 <- round(binom.test(6, 15)$conf.int, 2); ci88 <- round(binom.test(1, 13)$conf.int, 2)
cat("exact 95% CI, age 85 (6/15):", ci85, "; age 88 (1/13):", ci88, "\n\n")

## ---- Step 4: spectrum + target next to nuisance ---------------------------
cat("Step 4 — the target next to the nuisance:\n")
or_row <- function(fit) {
  b  <- unname(coef(fit)["early_vasopressor"])
  se <- unname(sqrt(vcov(fit)["early_vasopressor", "early_vasopressor"]))
  c(parameters = length(coef(fit)), logOR = b, SE = se, OR = exp(b),
    lcl = exp(b - 1.96 * se), ucl = exp(b + 1.96 * se))
}
print(round(rbind(
  age_linear    = or_row(glm(hospital_death ~ early_vasopressor + age,
                             family = binomial, data = coh)),
  age_spline    = or_row(glm(hospital_death ~ early_vasopressor + ns(age, df = 4),
                             family = binomial, data = coh)),
  age_saturated = or_row(glm(hospital_death ~ early_vasopressor + factor(age),
                             family = binomial, data = coh))), 3))
cat("# expect OR 2.163 / 2.137 / 2.375; SE 0.483 / 0.482 / 0.517\n")
print(coh |>
        group_by(age) |>
        summarise(exposed = sum(early_vasopressor)) |>
        summarise(strata_with_an_exposed_patient = sum(exposed > 0)))
cat("# expect 19 of 73\n")
cat("exposed patients' ages:", sort(coh$age[coh$early_vasopressor == 1]), "\n")
